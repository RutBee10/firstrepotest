const { useState, useEffect } = React;

function App() {
  const [models, setModels] = useState([]);
  const [selected, setSelected] = useState({ Claude: true }); // default Claude
  const [prompt, setPrompt] = useState('');
  const [fileId, setFileId] = useState('');
  const [outputs, setOutputs] = useState({});

  useEffect(() => {
    // fetch available models on mount
    fetch('/api/models')
      .then(res => res.json())
      .then(setModels)
      .catch(console.error);
  }, []);

  const toggleModel = (model) => {
    setSelected(prev => ({ ...prev, [model]: !prev[model] }));
  };

  const handleUpload = async (e) => {
    const files = e.target.files;
    if (!files.length) return;
    const form = new FormData();
    for (let f of files) form.append('files', f);
    const res = await fetch('/api/upload', { method: 'POST', body: form });
    const id = await res.text();
    setFileId(id);
    alert('Files uploaded, ID: ' + id);
  };

  const handleSubmit = async () => {
    const chosen = Object.entries(selected)
      .filter(([, v]) => v)
      .map(([k]) => k.toLowerCase());
    const body = {
      models: chosen,
      prompt,
      combinedText: prompt + (fileId ? '\n' + fileId : '')
    };
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    const data = await res.json();
    setOutputs(data);
  };

  const download = async (model) => {
    const res = await fetch(`/api/download/${fileId}`);
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${model}_output.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="container">
      <h1>Multi‑LLM AI Assistant</h1>
      <section className="model-panel">
        <h2>Select Models</h2>
        {models.map(m => (
          <label key={m}>
            <input type="checkbox" checked={!!selected[m]} onChange={() => toggleModel(m)} /> {m}
          </label>
        ))}
      </section>
      <section className="input-panel">
        <h2>Prompt</h2>
        <textarea value={prompt} onChange={e => setPrompt(e.target.value)} placeholder="Enter your prompt..." />
        <div>
          <input type="file" multiple onChange={handleUpload} accept=".pdf,.docx,.txt" />
        </div>
        <button onClick={handleSubmit}>Generate</button>
      </section>
      <section className="output-panel">
        <h2>Outputs</h2>
        {Object.entries(outputs).map(([model, resp]) => (
          <div className="output-card" key={model}>
            <h3>{model}</h3>
            <pre>{resp.output || resp.error}</pre>
            <button className="copy-btn" onClick={() => navigator.clipboard.writeText(resp.output || resp.error)}>Copy</button>
            {fileId && <button className="download-btn" onClick={() => download(model)}>Download</button>}
          </div>
        ))}
      </section>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
