package com.aiapp.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "llm")
public class LlmConfig {
    private ProviderConfig claude;
    private ProviderConfig openai;
    private ProviderConfig perplexity;
    private ProviderConfig gemini;
    private ProviderConfig copilot;
    private ProviderConfig ollama;

    // getters and setters
    public ProviderConfig getClaude() { return claude; }
    public void setClaude(ProviderConfig claude) { this.claude = claude; }
    public ProviderConfig getOpenai() { return openai; }
    public void setOpenai(ProviderConfig openai) { this.openai = openai; }
    public ProviderConfig getPerplexity() { return perplexity; }
    public void setPerplexity(ProviderConfig perplexity) { this.perplexity = perplexity; }
    public ProviderConfig getGemini() { return gemini; }
    public void setGemini(ProviderConfig gemini) { this.gemini = gemini; }
    public ProviderConfig getCopilot() { return copilot; }
    public void setCopilot(ProviderConfig copilot) { this.copilot = copilot; }
    public ProviderConfig getOllama() { return ollama; }
    public void setOllama(ProviderConfig ollama) { this.ollama = ollama; }

    public static class ProviderConfig {
        private String apiKey;
        private String model;
        private String endpoint;
        // getters and setters
        public String getApiKey() { return apiKey; }
        public void setApiKey(String apiKey) { this.apiKey = apiKey; }
        public String getModel() { return model; }
        public void setModel(String model) { this.model = model; }
        public String getEndpoint() { return endpoint; }
        public void setEndpoint(String endpoint) { this.endpoint = endpoint; }
    }
}
