package com.aiapp.model;

import java.util.List;

public class LlmRequest {
    private List<String> models; // e.g., ["claude", "openai"]
    private String prompt;
    private String combinedText; // prompt + extracted document text

    // getters and setters
    public List<String> getModels() { return models; }
    public void setModels(List<String> models) { this.models = models; }
    public String getPrompt() { return prompt; }
    public void setPrompt(String prompt) { this.prompt = prompt; }
    public String getCombinedText() { return combinedText; }
    public void setCombinedText(String combinedText) { this.combinedText = combinedText; }
}
