package com.aiapp.util;

import org.apache.tika.Tika;
import org.apache.tika.exception.TikaException;
import org.springframework.stereotype.Component;
import java.io.IOException;
import java.io.InputStream;

@Component
public class DocumentParser {
    private final Tika tika = new Tika();

    public String extractText(InputStream stream) throws IOException, TikaException {
        try {
            return tika.parseToString(stream);
        } catch (TikaException e) {
            throw new TikaException("Failed to parse document: " + e.getMessage(), e);
        }
    }
}
