package com.aiapp.controller;

import com.aiapp.util.DocumentParser;
import org.apache.tika.exception.TikaException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.UUID;

@RestController
@RequestMapping("/api")
public class FileController {

    @Autowired
    private DocumentParser parser;

    // Simple in‑memory store for extracted text keyed by UUID (for demo purposes)
    private final java.util.Map<String, String> store = new java.util.concurrent.ConcurrentHashMap<>();

    @PostMapping("/upload")
    public ResponseEntity<String> upload(@RequestParam("files") MultipartFile[] files) throws IOException, TikaException {
        StringBuilder combined = new StringBuilder();
        for (MultipartFile file : files) {
            String text = parser.extractText(file.getInputStream());
            combined.append(text).append("\n");
        }
        String id = UUID.randomUUID().toString();
        store.put(id, combined.toString());
        return ResponseEntity.ok(id); // client can use this id as part of LlmRequest.combinedText
    }

    @GetMapping("/download/{id}")
    public ResponseEntity<byte[]> download(@PathVariable String id) {
        String content = store.get(id);
        if (content == null) {
            return ResponseEntity.notFound().build();
        }
        byte[] bytes = content.getBytes(java.nio.charset.StandardCharsets.UTF_8);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"output.txt\"")
                .contentLength(bytes.length)
                .contentType(MediaType.TEXT_PLAIN)
                .body(bytes);
    }
}
