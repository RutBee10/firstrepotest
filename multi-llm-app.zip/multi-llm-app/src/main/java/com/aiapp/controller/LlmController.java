package com.aiapp.controller;

import com.aiapp.model.LlmRequest;
import com.aiapp.model.LlmResponse;
import com.aiapp.service.LlmOrchestrator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class LlmController {

    @Autowired
    private LlmOrchestrator orchestrator;

    @GetMapping("/models")
    public ResponseEntity<String[]> getAvailableModels() {
        // Hard‑coded list matching services
        String[] models = {"Claude", "ChatGPT", "Perplexity", "Gemini", "Copilot", "Ollama"};
        return ResponseEntity.ok(models);
    }

    @PostMapping("/chat")
    public ResponseEntity<Map<String, LlmResponse>> chat(@RequestBody LlmRequest request) throws Exception {
        Map<String, LlmResponse> results = orchestrator.dispatch(request);
        return ResponseEntity.ok(results);
    }
}
