package com.aiapp.service;

import com.aiapp.model.LlmRequest;
import com.aiapp.model.LlmResponse;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.concurrent.*;

@Service
public class LlmOrchestrator {
    private final ClaudeService claudeService;
    private final OpenAiService openAiService;
    private final PerplexityService perplexityService;
    private final GeminiService geminiService;
    private final CopilotService copilotService;
    private final OllamaService ollamaService;

    public LlmOrchestrator(ClaudeService claudeService, OpenAiService openAiService,
                           PerplexityService perplexityService, GeminiService geminiService,
                           CopilotService copilotService, OllamaService ollamaService) {
        this.claudeService = claudeService;
        this.openAiService = openAiService;
        this.perplexityService = perplexityService;
        this.geminiService = geminiService;
        this.copilotService = copilotService;
        this.ollamaService = ollamaService;
    }

    public Map<String, LlmResponse> dispatch(LlmRequest request) throws Exception {
        List<String> models = request.getModels();
        String prompt = request.getCombinedText();
        Map<String, CompletableFuture<LlmResponse>> futures = new HashMap<>();
        for (String model : models) {
            switch (model.toLowerCase()) {
                case "claude":
                    futures.put("Claude", CompletableFuture.supplyAsync(() -> {
                        try { return claudeService.generate(prompt); } catch (Exception e) { return errorResponse("Claude", e); }
                    }));
                    break;
                case "chatgpt":
                case "openai":
                    futures.put("ChatGPT", CompletableFuture.supplyAsync(() -> {
                        try { return openAiService.generate(prompt); } catch (Exception e) { return errorResponse("ChatGPT", e); }
                    }));
                    break;
                case "perplexity":
                    futures.put("Perplexity", CompletableFuture.supplyAsync(() -> {
                        try { return perplexityService.generate(prompt); } catch (Exception e) { return errorResponse("Perplexity", e); }
                    }));
                    break;
                case "gemini":
                    futures.put("Gemini", CompletableFuture.supplyAsync(() -> {
                        try { return geminiService.generate(prompt); } catch (Exception e) { return errorResponse("Gemini", e); }
                    }));
                    break;
                case "copilot":
                    futures.put("Copilot", CompletableFuture.supplyAsync(() -> {
                        try { return copilotService.generate(prompt); } catch (Exception e) { return errorResponse("Copilot", e); }
                    }));
                    break;
                case "ollama":
                    futures.put("Ollama", CompletableFuture.supplyAsync(() -> {
                        try { return ollamaService.generate(prompt); } catch (Exception e) { return errorResponse("Ollama", e); }
                    }));
                    break;
                default:
                    // ignore unknown
            }
        }
        // Wait for all
        CompletableFuture.allOf(futures.values().toArray(new CompletableFuture[0])).join();
        Map<String, LlmResponse> results = new HashMap<>();
        for (Map.Entry<String, CompletableFuture<LlmResponse>> entry : futures.entrySet()) {
            results.put(entry.getKey(), entry.getValue().get());
        }
        return results;
    }

    private LlmResponse errorResponse(String model, Exception e) {
        LlmResponse r = new LlmResponse();
        r.setModelName(model);
        r.setError(e.getMessage());
        return r;
    }
}
