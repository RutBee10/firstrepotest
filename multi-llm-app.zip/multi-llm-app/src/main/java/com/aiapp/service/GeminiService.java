package com.aiapp.service;

import com.aiapp.config.LlmConfig;
import com.aiapp.config.LlmConfig.ProviderConfig;
import com.aiapp.model.LlmResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import okhttp3.*;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.io.IOException;

@Service
public class GeminiService {
    private final ProviderConfig config;
    private final OkHttpClient client = new OkHttpClient();
    private final ObjectMapper objectMapper = new ObjectMapper();


    @Autowired
    public GeminiService(LlmConfig llmConfig) {
        this.config = llmConfig.getGemini();
    }

    public LlmResponse generate(String combinedPrompt) throws IOException {
        MediaType JSON = MediaType.get("application/json; charset=utf-8");

        ObjectNode root1 = objectMapper.createObjectNode();

        ArrayNode contents = root1.putArray("contents");
        ObjectNode content = contents.addObject();
        content.put("role", "user");

        ArrayNode parts = content.putArray("parts");
        parts.addObject().put("text", combinedPrompt.replaceAll("\\r\\n|\\r|\\n", " "));

        ObjectNode generationConfig = root1.putObject("generationConfig");
        generationConfig.put("maxOutputTokens", 4096);
        generationConfig.put("temperature", 0.7);

        String bodyJson = root1.toString();

        String url = config.getEndpoint().replace("${model}", config.getModel()) + "?key=" + config.getApiKey();
        Request request = new Request.Builder()
                .url(url)
                .post(RequestBody.create(bodyJson, JSON))
                .build();
        try (Response response = client.newCall(request).execute()) {
            LlmResponse llmResponse = new LlmResponse();
            llmResponse.setModelName("Gemini");
            if (!response.isSuccessful()) {
                llmResponse.setError("Gemini API error: " + response.code());
                return llmResponse;
            }
            String responseBody = response.body().string();
            JsonNode root = objectMapper.readTree(responseBody);
            JsonNode textNode = root.path("candidates").path(0).path("content").path("parts").path(0).path("text");
            llmResponse.setOutput(textNode.isMissingNode() ? responseBody : textNode.asText());
            //llmResponse.setOutput(response.body().string());
            return llmResponse;
        }
    }
}
