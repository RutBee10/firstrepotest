package com.aiapp.service;

import com.aiapp.config.LlmConfig;
import com.aiapp.config.LlmConfig.ProviderConfig;
import com.aiapp.model.LlmResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import okhttp3.*;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.io.IOException;

@Service
public class OllamaService {
    private final ProviderConfig config;
    private final OkHttpClient client = new OkHttpClient();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Autowired
    public OllamaService(LlmConfig llmConfig) {
        this.config = llmConfig.getOllama();
    }

    public LlmResponse generate(String combinedPrompt) throws IOException {
        MediaType JSON = MediaType.get("application/json; charset=utf-8");
        String bodyJson = "{\"model\": \"" + config.getModel() + "\", \"messages\": [{\"role\": \"user\", \"content\": \"" + combinedPrompt.replaceAll("\\r\\n|\\r|\\n", " ")+ "\"}],\"stream\": false}";
        Request request = new Request.Builder()
                .url(config.getEndpoint())
                .post(RequestBody.create(bodyJson, JSON))
                .build();
        try (Response response = client.newCall(request).execute()) {
            LlmResponse llmResponse = new LlmResponse();
            llmResponse.setModelName("Ollama");
            if (!response.isSuccessful()) {
                llmResponse.setError("Ollama API error: " + response.code());
                return llmResponse;
            }

            String responseBody = response.body().string();
            JsonNode root = objectMapper.readTree(responseBody);
            JsonNode textNode = root.path("message").path("content");
            llmResponse.setOutput(textNode.isMissingNode() ? responseBody : textNode.asText());
            //llmResponse.setOutput(response.body().string());
            return llmResponse;
        }
    }
}
