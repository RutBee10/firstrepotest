package com.aiapp.service;

import com.aiapp.config.LlmConfig;
import com.aiapp.config.LlmConfig.ProviderConfig;
import com.aiapp.model.LlmResponse;
import okhttp3.*;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.io.IOException;

@Service
public class OpenAiService {
    private final ProviderConfig config;
    private final OkHttpClient client = new OkHttpClient();

    @Autowired
    public OpenAiService(LlmConfig llmConfig) {
        this.config = llmConfig.getOpenai();
    }

    public LlmResponse generate(String combinedPrompt) throws IOException {
        MediaType JSON = MediaType.get("application/json; charset=utf-8");
        String bodyJson = "{\"model\": \"" + config.getModel() + "\", \"messages\": [{\"role\": \"user\", \"content\": \"" + combinedPrompt + "\"}]}";
        Request request = new Request.Builder()
                .url(config.getEndpoint())
                .addHeader("Authorization", "Bearer " + config.getApiKey())
                .post(RequestBody.create(bodyJson, JSON))
                .build();
        try (Response response = client.newCall(request).execute()) {
            LlmResponse llmResponse = new LlmResponse();
            llmResponse.setModelName("ChatGPT");
            if (!response.isSuccessful()) {
                llmResponse.setError("OpenAI API error: " + response.code());
                return llmResponse;
            }
            llmResponse.setOutput(response.body().string());
            return llmResponse;
        }
    }
}
