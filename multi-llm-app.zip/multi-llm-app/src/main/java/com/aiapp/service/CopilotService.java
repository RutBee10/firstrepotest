package com.aiapp.service;

import com.aiapp.config.LlmConfig;
import com.aiapp.config.LlmConfig.ProviderConfig;
import com.aiapp.model.LlmResponse;
import okhttp3.*;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.io.IOException;

@Service
public class CopilotService {
    private final ProviderConfig config;
    private final OkHttpClient client = new OkHttpClient();

    @Autowired
    public CopilotService(LlmConfig llmConfig) {
        this.config = llmConfig.getCopilot();
    }

    public LlmResponse generate(String combinedPrompt) throws IOException {
        MediaType JSON = MediaType.get("application/json; charset=utf-8");
        String bodyJson = "{\"model\": \"" + config.getModel() + "\", \"messages\": [{\"role\": \"user\", \"content\": \"" + combinedPrompt + "\"}]}";
        Request request = new Request.Builder()
                .url(config.getEndpoint())
                .addHeader("api-key", config.getApiKey())
                .post(RequestBody.create(bodyJson, JSON))
                .build();
        try (Response response = client.newCall(request).execute()) {
            LlmResponse llmResponse = new LlmResponse();
            llmResponse.setModelName("Copilot");
            if (!response.isSuccessful()) {
                llmResponse.setError("Copilot API error: " + response.code());
                return llmResponse;
            }
            llmResponse.setOutput(response.body().string());
            return llmResponse;
        }
    }
}
