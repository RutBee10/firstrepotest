# 🐟 MiroFish — Swarm Intelligence Prediction Engine
### Spring Boot + Gradle Edition

A multi-agent AI prediction engine that constructs a digital sandbox for scenario simulation.
Upload any document, ask a prediction question, and watch AI agents simulate real social dynamics to predict your future trend.

---

## ⚡ Quick Start

### 1. Place Gradle Wrapper JAR
The `gradle-wrapper.jar` must be in `gradle/wrapper/` before first use.

```bash
# If Gradle is installed:
gradle wrapper --gradle-version 8.6

# Or download directly:
curl -L "https://github.com/gradle/gradle/raw/v8.6.0/gradle/wrapper/gradle-wrapper.jar" \
     -o gradle/wrapper/gradle-wrapper.jar
```

### 2. Configure LLM in application.properties
```properties
llm.api-key=Ollama
llm.base-url=http://localhost:11434/v1
llm.model-name=qwen3.5:cloud
```
> Leave `llm.api-key=YOUR_API_KEY_HERE` for **Demo Mode** — full UI with rich simulated responses, zero API cost.

### 3. Run
```bash
./gradlew bootRun          # Linux/macOS
gradlew.bat bootRun        # Windows
```

Open: **http://localhost:9090**

---

## 🔧 Common Gradle Commands

| Command | Description |
|---------|-------------|
| `./gradlew bootRun` | Run the application |
| `./gradlew bootJar` | Build fat JAR → `build/libs/mirofish-1.0.0.jar` |
| `./gradlew test` | Run tests |
| `./gradlew clean bootJar` | Clean + build |
| `java -jar build/libs/mirofish-1.0.0.jar` | Run built JAR directly |

---

## 🌐 LLM Providers (any OpenAI-compatible)

| Provider | base-url | model-name |
|----------|----------|------------|
| Ollama (local/free) | `http://localhost:11434/v1` | `qwen3.5:cloud`, `llama3.2`, etc. |
| OpenAI | `https://api.openai.com/v1` | `gpt-4o-mini`, `gpt-4o` |
| Alibaba Qwen | `https://dashscope.aliyuncs.com/compatible-mode/v1` | `qwen-plus` |
| OpenRouter | `https://openrouter.ai/api/v1` | any model |
| LM Studio | `http://localhost:1234/v1` | any local model |

---

## 🔄 The 5-Stage Pipeline

```
Seed Material
    ↓
[Stage 1] Knowledge Graph Extraction  (EXTRACTING_GRAPH)
    ↓
[Stage 2] Agent Persona Creation      (CREATING_AGENTS)
    ↓
[Stage 3] Dual-Platform Simulation    (SIMULATING)
           Twitter + Reddit agents interact, opinions evolve
    ↓
[Stage 4] Report Generation           (GENERATING_REPORT)
    ↓
[Stage 5] Deep Interaction            (COMPLETED)
           Chat with any agent or the ReportAgent
```

---

## 📁 Project Structure

```
src/main/java/com/mirofish/
├── MiroFishApplication.java
├── config/     LlmConfig.java
├── controller/ MiroFishController.java
├── dto/        SimulationCreateRequest.java
├── model/      Simulation.java, Agent.java, SimulationPost.java, ChatMessage.java
├── repository/ SimulationRepository.java, AgentRepository.java,
│               SimulationPostRepository.java, ChatMessageRepository.java
└── service/    LlmService.java, SimulationService.java,
                ChatService.java, FileService.java

src/main/resources/
├── application.properties
├── templates/  index.html, new-simulation.html, simulation.html,
│               agents.html, chat.html
└── static/css/ app.css
```

---

## 🗄️ Switch to PostgreSQL

1. Add to `build.gradle.kts`:
```kotlin
runtimeOnly("org.postgresql:postgresql")
// comment out: runtimeOnly("com.h2database:h2")
```

2. Update `application.properties`:
```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/mirofishdb
spring.datasource.username=postgres
spring.datasource.password=yourpassword
spring.jpa.database-platform=org.hibernate.dialect.PostgreSQLDialect
```

---

## 💡 Cost Tips

- Start with **5 agents × 5 rounds** to test
- Use Ollama (free, local) for zero-cost simulations
- `gpt-4o-mini` costs ~$0.03 per typical 20-agent/10-round simulation
- Demo Mode costs **$0.00** and demonstrates full functionality
