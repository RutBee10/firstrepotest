package com.mirofish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

@SpringBootTest
@TestPropertySource(properties = {
    "llm.api-key=test-key",
    "llm.base-url=http://localhost:11434/v1",
    "llm.model-name=qwen3.5:cloud"
})
class MiroFishApplicationTests {
    @Test
    void contextLoads() {}
}
