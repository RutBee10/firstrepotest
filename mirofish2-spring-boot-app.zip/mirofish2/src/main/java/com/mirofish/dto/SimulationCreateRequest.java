package com.mirofish.dto;

import lombok.Data;

@Data
public class SimulationCreateRequest {
    private String title;
    private String predictionQuery;
    private String seedText;
    private int agentCount = 20;
    private int rounds     = 10;
}
