package com.mirofish.config;

import okhttp3.OkHttpClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.TimeUnit;

@Configuration
public class LlmConfig {

    @Value("${llm.api-key}")
    private String apiKey;

    @Value("${llm.base-url}")
    private String baseUrl;

    @Value("${llm.model-name}")
    private String modelName;

    @Bean
    public OkHttpClient okHttpClient() {
        return new OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(180, TimeUnit.SECONDS)   // LLMs can be slow
                .writeTimeout(60, TimeUnit.SECONDS)
                .build();
    }

    public String getApiKey()    { return apiKey; }
    public String getBaseUrl()   { return baseUrl; }
    public String getModelName() { return modelName; }

    /** Demo mode: no real LLM calls, simulated responses only */
    public boolean isDemoMode() {
        return apiKey == null || apiKey.isBlank() || apiKey.equals("YOUR_API_KEY_HERE");
    }
}
