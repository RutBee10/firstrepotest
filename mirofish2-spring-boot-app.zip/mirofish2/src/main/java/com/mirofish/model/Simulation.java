package com.mirofish.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "simulations")
@Data
@NoArgsConstructor
public class Simulation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 300)
    private String title;

    /** The user's prediction question / topic */
    @Column(nullable = false, length = 2000)
    private String predictionQuery;

    /** Raw seed text (from upload or textarea) */
    @Column(columnDefinition = "TEXT")
    private String seedText;

    @Column(nullable = false)
    private Integer agentCount = 20;

    @Column(nullable = false)
    private Integer rounds = 10;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status = Status.PENDING;

    /** JSON knowledge graph extracted from seed material */
    @Column(columnDefinition = "TEXT")
    private String knowledgeGraphJson;

    /** Structured final prediction report (markdown) */
    @Column(columnDefinition = "TEXT")
    private String reportMarkdown;

    /** Simulation activity log */
    @Column(columnDefinition = "TEXT")
    private String simulationLog;

    /** Error message if status = FAILED */
    @Column(length = 1000)
    private String errorMessage;

    private LocalDateTime createdAt;
    private LocalDateTime completedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    public enum Status {
        PENDING,
        EXTRACTING_GRAPH,
        CREATING_AGENTS,
        SIMULATING,
        GENERATING_REPORT,
        COMPLETED,
        FAILED
    }

    public boolean isRunning() {
        return status == Status.PENDING
            || status == Status.EXTRACTING_GRAPH
            || status == Status.CREATING_AGENTS
            || status == Status.SIMULATING
            || status == Status.GENERATING_REPORT;
    }

    public String getStatusLabel() {
        return switch (status) {
            case PENDING           -> "Pending";
            case EXTRACTING_GRAPH  -> "Building Knowledge Graph...";
            case CREATING_AGENTS   -> "Spawning Agents...";
            case SIMULATING        -> "Running Simulation...";
            case GENERATING_REPORT -> "Generating Report...";
            case COMPLETED         -> "Completed";
            case FAILED            -> "Failed";
        };
    }
}
