package com.mirofish.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "agents")
@Data
@NoArgsConstructor
public class Agent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "simulation_id", nullable = false)
    private Simulation simulation;

    /** Agent's display name */
    @Column(nullable = false, length = 100)
    private String name;

    /** One-paragraph professional/personal background */
    @Column(length = 1000)
    private String background;

    /** Core personality trait: analytical, optimistic, skeptical, empathetic, etc. */
    @Column(length = 200)
    private String personality;

    /** Agent's stance at simulation start */
    @Column(columnDefinition = "TEXT")
    private String initialOpinion;

    /** Agent's stance at the end — may shift from initial */
    @Column(columnDefinition = "TEXT")
    private String currentOpinion;

    /** TWITTER or REDDIT */
    @Column(nullable = false, length = 20)
    private String platform = "TWITTER";

    /** 1-100 relative influence score */
    private int influenceScore = 50;

    /** 0.0-1.0: how much opinion shifted across simulation */
    private double opinionShift = 0.0;
}
