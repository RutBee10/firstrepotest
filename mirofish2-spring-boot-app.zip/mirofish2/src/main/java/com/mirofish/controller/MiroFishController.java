package com.mirofish.controller;

import com.mirofish.config.LlmConfig;
import com.mirofish.model.*;
import com.mirofish.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;
import java.util.stream.Collectors;

@Controller
public class MiroFishController {

    @Autowired private SimulationService simService;
    @Autowired private ChatService       chatService;
    @Autowired private FileService       fileService;
    @Autowired private LlmConfig         llmConfig;

    // ─── Pages ───────────────────────────────────────────────────────────────

    /** Home: list all simulations */
    @GetMapping("/")
    public String home(Model m) {
        m.addAttribute("simulations", simService.listAll());
        m.addAttribute("demoMode",    llmConfig.isDemoMode());
        m.addAttribute("llmModel",    llmConfig.getModelName());
        return "index";
    }

    /** New simulation form */
    @GetMapping("/new")
    public String newForm(Model m) {
        m.addAttribute("demoMode", llmConfig.isDemoMode());
        return "new-simulation";
    }

    /** Simulation detail / results page */
    @GetMapping("/simulation/{id}")
    public String detail(@PathVariable Long id, Model m) {
        Simulation sim = simService.findById(id).orElse(null);
        if (sim == null) return "redirect:/";

        List<Agent>          agents      = simService.getAgents(id);
        List<SimulationPost> posts       = simService.getPosts(id);
        List<SimulationPost> twitterPosts = posts.stream().filter(p -> "TWITTER".equals(p.getPlatform())).collect(Collectors.toList());
        List<SimulationPost> redditPosts  = posts.stream().filter(p -> "REDDIT".equals(p.getPlatform())).collect(Collectors.toList());

        // Chart data
        List<String> agentNames    = agents.stream().map(Agent::getName).collect(Collectors.toList());
        List<Double> opinionShifts = agents.stream().map(a -> Math.round(a.getOpinionShift() * 1000.0) / 10.0).collect(Collectors.toList());

        // Platform distribution
        long twitterCount = agents.stream().filter(a -> "TWITTER".equals(a.getPlatform())).count();
        long redditCount  = agents.size() - twitterCount;

        m.addAttribute("sim",           sim);
        m.addAttribute("agents",        agents);
        m.addAttribute("twitterPosts",  twitterPosts);
        m.addAttribute("redditPosts",   redditPosts);
        m.addAttribute("totalPosts",    posts.size());
        m.addAttribute("agentNames",    agentNames);
        m.addAttribute("opinionShifts", opinionShifts);
        m.addAttribute("twitterCount",  twitterCount);
        m.addAttribute("redditCount",   redditCount);
        m.addAttribute("demoMode",      llmConfig.isDemoMode());
        return "simulation";
    }

    /** Agents explorer page */
    @GetMapping("/simulation/{id}/agents")
    public String agents(@PathVariable Long id, Model m) {
        Simulation sim = simService.findById(id).orElse(null);
        if (sim == null) return "redirect:/";
        m.addAttribute("sim",    sim);
        m.addAttribute("agents", simService.getAgents(id));
        return "agents";
    }

    /** Chat interface */
    @GetMapping("/simulation/{id}/chat")
    public String chat(@PathVariable Long id,
                       @RequestParam(required = false) Long agentId,
                       Model m) {
        Simulation sim = simService.findById(id).orElse(null);
        if (sim == null) return "redirect:/";
        m.addAttribute("sim",             sim);
        m.addAttribute("agents",          simService.getAgents(id));
        m.addAttribute("selectedAgentId", agentId);
        return "chat";
    }

    // ─── Form Submit ──────────────────────────────────────────────────────────

    @PostMapping("/simulation/create")
    public String create(
            @RequestParam                    String      title,
            @RequestParam                    String      predictionQuery,
            @RequestParam(required = false)  String      seedText,
            @RequestParam(required = false)  MultipartFile seedFile,
            @RequestParam(defaultValue = "20") int       agentCount,
            @RequestParam(defaultValue = "10") int       rounds) {

        try {
            // Combine file + textarea text
            String extracted = "";
            if (seedFile != null && !seedFile.isEmpty()) {
                extracted = fileService.extractText(seedFile);
            }
            String finalSeed = (extracted + "\n" + (seedText != null ? seedText : "")).trim();
            if (finalSeed.isBlank()) finalSeed = "General context for prediction topic: " + predictionQuery;

            Simulation sim = simService.create(title, predictionQuery, finalSeed, agentCount, rounds);
            simService.runPipeline(sim.getId()); // @Async — returns immediately
            return "redirect:/simulation/" + sim.getId();
        } catch (Exception e) {
            return "redirect:/?error=" + e.getMessage();
        }
    }

    // ─── REST API (called by JS) ──────────────────────────────────────────────

    @GetMapping("/api/simulation/{id}/status")
    @ResponseBody
    public Map<String, Object> status(@PathVariable Long id) {
        try { return simService.getStatusSnapshot(id); }
        catch (Exception e) { return Map.of("error", e.getMessage()); }
    }

    @PostMapping("/api/simulation/{id}/chat/agent")
    @ResponseBody
    public Map<String, String> chatAgent(
            @PathVariable Long id,
            @RequestParam Long   agentId,
            @RequestParam String message) {
        try {
            return Map.of("reply", chatService.chatWithAgent(id, agentId, message));
        } catch (Exception e) {
            return Map.of("reply", "Error: " + e.getMessage());
        }
    }

    @PostMapping("/api/simulation/{id}/chat/report")
    @ResponseBody
    public Map<String, String> chatReport(
            @PathVariable Long id,
            @RequestParam String message) {
        try {
            return Map.of("reply", chatService.chatWithReportAgent(id, message));
        } catch (Exception e) {
            return Map.of("reply", "Error: " + e.getMessage());
        }
    }

    @DeleteMapping("/api/simulation/{id}")
    @ResponseBody
    public Map<String, String> delete(@PathVariable Long id) {
        try {
            simService.delete(id);
            return Map.of("result", "deleted");
        } catch (Exception e) {
            return Map.of("error", e.getMessage());
        }
    }
}
