package com.mirofish.repository;

import com.mirofish.model.Simulation;
import com.mirofish.model.SimulationPost;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SimulationPostRepository extends JpaRepository<SimulationPost, Long> {
    List<SimulationPost> findBySimulationOrderByRoundAscPostedAtAsc(Simulation simulation);
    List<SimulationPost> findBySimulationAndPlatformOrderByRoundAscPostedAtAsc(Simulation sim, String platform);
    long countBySimulation(Simulation simulation);
}
