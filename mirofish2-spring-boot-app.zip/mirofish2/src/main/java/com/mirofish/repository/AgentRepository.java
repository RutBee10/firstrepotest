package com.mirofish.repository;

import com.mirofish.model.Agent;
import com.mirofish.model.Simulation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AgentRepository extends JpaRepository<Agent, Long> {
    List<Agent> findBySimulationOrderByInfluenceScoreDesc(Simulation simulation);
    List<Agent> findBySimulationAndPlatform(Simulation simulation, String platform);
    long countBySimulation(Simulation simulation);
}
