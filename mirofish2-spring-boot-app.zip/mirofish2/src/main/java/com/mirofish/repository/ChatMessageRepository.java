package com.mirofish.repository;

import com.mirofish.model.ChatMessage;
import com.mirofish.model.Simulation;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {
    List<ChatMessage> findBySimulationAndAgentIdOrderByCreatedAtAsc(Simulation sim, Long agentId);
}
