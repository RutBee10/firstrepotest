package com.mirofish.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mirofish.model.*;
import com.mirofish.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Core MiroFish simulation pipeline.
 *
 * Stage 1 — EXTRACTING_GRAPH   : Build knowledge graph from seed text
 * Stage 2 — CREATING_AGENTS    : Spawn AI agents with unique personas
 * Stage 3 — SIMULATING         : Run N rounds of dual-platform interaction
 * Stage 4 — GENERATING_REPORT  : Synthesize prediction report
 * Stage 5 — COMPLETED          : Deep interaction mode (via ChatService)
 */
@Service
public class SimulationService {

    private static final Logger log = LoggerFactory.getLogger(SimulationService.class);

    @Autowired private SimulationRepository    simRepo;
    @Autowired private AgentRepository         agentRepo;
    @Autowired private SimulationPostRepository postRepo;
    @Autowired private LlmService              llm;

    private final ObjectMapper mapper = new ObjectMapper();
    private final Random       rng    = new Random();

    // ─────────────────────────────────────────────────────────────────────────
    //  Public API
    // ─────────────────────────────────────────────────────────────────────────

    public List<Simulation> listAll() {
        return simRepo.findAllByOrderByCreatedAtDesc();
    }

    public Optional<Simulation> findById(Long id) {
        return simRepo.findById(id);
    }

    public Simulation create(String title, String query, String seedText,
                             int agentCount, int rounds) {
        Simulation sim = new Simulation();
        sim.setTitle(title);
        sim.setPredictionQuery(query);
        sim.setSeedText(seedText);
        sim.setAgentCount(Math.min(Math.max(agentCount, 3), 50));
        sim.setRounds(Math.min(Math.max(rounds, 1), 40));
        sim.setStatus(Simulation.Status.PENDING);
        return simRepo.save(sim);
    }

    public List<Agent> getAgents(Long simId) {
        Simulation sim = simRepo.findById(simId).orElseThrow();
        return agentRepo.findBySimulationOrderByInfluenceScoreDesc(sim);
    }

    public List<SimulationPost> getPosts(Long simId) {
        Simulation sim = simRepo.findById(simId).orElseThrow();
        return postRepo.findBySimulationOrderByRoundAscPostedAtAsc(sim);
    }

    public Map<String, Object> getStatusSnapshot(Long simId) {
        Simulation sim = simRepo.findById(simId).orElseThrow();
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id",          sim.getId());
        m.put("status",      sim.getStatus().name());
        m.put("statusLabel", sim.getStatusLabel());
        m.put("agentCount",  agentRepo.countBySimulation(sim));
        m.put("postCount",   postRepo.countBySimulation(sim));
        m.put("hasReport",   sim.getReportMarkdown() != null);
        m.put("isRunning",   sim.isRunning());
        return m;
    }

    public void delete(Long simId) {
        simRepo.deleteById(simId);
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Async pipeline execution
    // ─────────────────────────────────────────────────────────────────────────

    @Async
    @Transactional
    public void runPipeline(Long simId) {
        Simulation sim = simRepo.findById(simId).orElseThrow();
        log.info("[Sim {}] Pipeline starting: '{}'", simId, sim.getTitle());

        try {
            // ── Stage 1: Knowledge Graph ─────────────────────────────────────
            setStatus(sim, Simulation.Status.EXTRACTING_GRAPH);
            log.info("[Sim {}] Stage 1: Extracting knowledge graph", simId);
            String kgJson = llm.extractKnowledgeGraph(sim.getSeedText());
            sim.setKnowledgeGraphJson(kgJson);
            simRepo.save(sim);

            String kgSummary = summariseKg(kgJson);

            // ── Stage 2: Agent Creation ──────────────────────────────────────
            setStatus(sim, Simulation.Status.CREATING_AGENTS);
            log.info("[Sim {}] Stage 2: Creating {} agents", simId, sim.getAgentCount());
            List<Agent> agents = spawnAgents(sim, kgSummary);

            // ── Stage 3: Simulation Rounds ───────────────────────────────────
            setStatus(sim, Simulation.Status.SIMULATING);
            log.info("[Sim {}] Stage 3: Running {} rounds", simId, sim.getRounds());
            StringBuilder activityLog = new StringBuilder();
            runRounds(sim, agents, activityLog);
            sim.setSimulationLog(activityLog.toString());
            simRepo.save(sim);

            // ── Stage 4: Report Generation ───────────────────────────────────
            setStatus(sim, Simulation.Status.GENERATING_REPORT);
            log.info("[Sim {}] Stage 4: Generating prediction report", simId);
            String report = buildReport(sim, agents);
            sim.setReportMarkdown(report);
            sim.setStatus(Simulation.Status.COMPLETED);
            sim.setCompletedAt(LocalDateTime.now());
            simRepo.save(sim);

            log.info("[Sim {}] Pipeline COMPLETED successfully", simId);

        } catch (Exception e) {
            log.error("[Sim {}] Pipeline FAILED: {}", simId, e.getMessage(), e);
            sim.setStatus(Simulation.Status.FAILED);
            sim.setErrorMessage(e.getMessage());
            simRepo.save(sim);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Stage implementations
    // ─────────────────────────────────────────────────────────────────────────

    private List<Agent> spawnAgents(Simulation sim, String kgSummary) {
        List<Agent> agents = new ArrayList<>();
        for (int i = 1; i <= sim.getAgentCount(); i++) {
            agents.add(spawnOneAgent(sim, kgSummary, i, sim.getAgentCount()));
            // Brief pause to avoid API rate limits
            sleep(200);
        }
        return agents;
    }

    private Agent spawnOneAgent(Simulation sim, String kgSummary, int idx, int total) {
        try {
            String json = llm.generatePersona(sim.getPredictionQuery(), kgSummary, idx, total);
            JsonNode node = mapper.readTree(json);

            Agent a = new Agent();
            a.setSimulation(sim);
            a.setName(           node.path("name").asText("Agent_" + idx));
            a.setBackground(     node.path("background").asText("Simulation participant"));
            a.setPersonality(    node.path("personality").asText("analytical"));
            a.setInitialOpinion( node.path("initialOpinion").asText("Awaiting more information"));
            a.setCurrentOpinion( a.getInitialOpinion());
            a.setPlatform(       "REDDIT".equals(node.path("platform").asText()) ? "REDDIT" : "TWITTER");
            a.setInfluenceScore( rng.nextInt(91) + 10); // 10-100
            a.setOpinionShift(   0.0);
            return agentRepo.save(a);

        } catch (Exception e) {
            log.warn("[Agent {}] Persona parse failed, using fallback: {}", idx, e.getMessage());
            Agent fallback = new Agent();
            fallback.setSimulation(sim);
            fallback.setName("Participant_" + idx);
            fallback.setBackground("A thoughtful observer with a diverse background");
            fallback.setPersonality(randomPersonality());
            fallback.setInitialOpinion("Still forming an opinion based on the available evidence");
            fallback.setCurrentOpinion(fallback.getInitialOpinion());
            fallback.setPlatform(idx % 2 == 0 ? "REDDIT" : "TWITTER");
            fallback.setInfluenceScore(rng.nextInt(91) + 10);
            return agentRepo.save(fallback);
        }
    }

    private void runRounds(Simulation sim, List<Agent> agents, StringBuilder log_) {
        for (int round = 1; round <= sim.getRounds(); round++) {
            log.info("[Sim {}] Round {}/{}", sim.getId(), round, sim.getRounds());
            log_.append("\n=== ROUND ").append(round).append(" ===\n");
            runOneRound(sim, agents, round, log_);

            // Update opinions every 2 rounds
            if (round % 2 == 0) {
                updateOpinions(sim, agents, log_);
            }
        }
    }

    private void runOneRound(Simulation sim, List<Agent> agents,
                              int round, StringBuilder log_) {
        // Shuffle agents each round for organic interaction
        List<Agent> shuffled = new ArrayList<>(agents);
        Collections.shuffle(shuffled, rng);

        // Limit API calls per round: post for up to 6 agents per round
        int postsPerRound = Math.min(shuffled.size(), 6);

        // Get recent context (last 8 posts)
        String context = getRecentPostContext(sim);

        for (int i = 0; i < postsPerRound; i++) {
            Agent agent = shuffled.get(i);
            try {
                String content = llm.generatePost(
                    agent.getName(), agent.getPersonality(),
                    agent.getCurrentOpinion(), agent.getPlatform(),
                    sim.getPredictionQuery(), context, round
                );
                content = content.trim();

                // Twitter: enforce 280 char limit
                if ("TWITTER".equals(agent.getPlatform()) && content.length() > 280) {
                    content = content.substring(0, 277) + "...";
                }

                SimulationPost post = new SimulationPost();
                post.setSimulation(sim);
                post.setAgent(agent);
                post.setContent(content);
                post.setPlatform(agent.getPlatform());
                post.setRound(round);
                post.setLikes(rng.nextInt(200));
                post.setShares(rng.nextInt(50));
                postRepo.save(post);

                log_.append("[").append(agent.getPlatform()).append("] ")
                    .append(agent.getName()).append(": ")
                    .append(content, 0, Math.min(80, content.length())).append("...\n");

                sleep(150);
            } catch (Exception e) {
                log.warn("[Sim {}] Post gen failed for {}: {}", sim.getId(), agent.getName(), e.getMessage());
            }
        }
    }

    private void updateOpinions(Simulation sim, List<Agent> agents, StringBuilder log_) {
        String recentPosts = getRecentPostContext(sim);
        // Update a random subset of agents (30%) each time
        agents.stream()
              .filter(a -> rng.nextDouble() < 0.3)
              .forEach(agent -> updateOneOpinion(sim, agent, recentPosts));
    }

    private void updateOneOpinion(Simulation sim, Agent agent, String recentPosts) {
        try {
            String json = llm.updateOpinion(
                agent.getName(), agent.getCurrentOpinion(),
                recentPosts, sim.getPredictionQuery()
            );
            JsonNode node = mapper.readTree(json);
            String updatedOpinion = node.path("updatedOpinion").asText(agent.getCurrentOpinion());
            double shift = node.path("shift").asDouble(0.0);

            agent.setCurrentOpinion(updatedOpinion);
            agent.setOpinionShift((agent.getOpinionShift() + shift) / 2.0); // rolling avg
            agentRepo.save(agent);
        } catch (Exception e) {
            log.debug("Opinion update failed for {}: {}", agent.getName(), e.getMessage());
        }
    }

    private String buildReport(Simulation sim, List<Agent> agents) {
        String agentChanges = agents.stream()
            .map(a -> String.format("• %s (%s/%s): \"%s\" → \"%s\" [shift: %.0f%%]",
                a.getName(), a.getPersonality(), a.getPlatform(),
                truncate(a.getInitialOpinion(), 60),
                truncate(a.getCurrentOpinion(), 60),
                a.getOpinionShift() * 100))
            .collect(Collectors.joining("\n"));

        return llm.generateReport(
            sim.getPredictionQuery(), agentChanges,
            sim.getSimulationLog() != null ? sim.getSimulationLog() : "",
            sim.getKnowledgeGraphJson()
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Helpers
    // ─────────────────────────────────────────────────────────────────────────

    private String getRecentPostContext(Simulation sim) {
        List<SimulationPost> recent = postRepo.findBySimulationOrderByRoundAscPostedAtAsc(sim);
        return recent.stream()
            .skip(Math.max(0, recent.size() - 12))
            .map(p -> "[" + p.getAgent().getName() + " on " + p.getPlatform() + "]: " + p.getContent())
            .collect(Collectors.joining("\n"));
    }

    private String summariseKg(String kgJson) {
        try {
            JsonNode node = mapper.readTree(kgJson);
            StringBuilder sb = new StringBuilder();
            if (node.has("entities")) {
                sb.append("Entities: ");
                node.get("entities").forEach(e -> sb.append(e.path("name").asText()).append(", "));
            }
            if (node.has("relationships")) {
                sb.append(" | Relations: ");
                node.get("relationships").forEach(r ->
                    sb.append(r.path("from").asText()).append("→").append(r.path("to").asText()).append(", "));
            }
            return sb.toString();
        } catch (Exception e) {
            return "Complex scenario with multiple interconnected entities";
        }
    }

    private void setStatus(Simulation sim, Simulation.Status status) {
        sim.setStatus(status);
        simRepo.save(sim);
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }

    private String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() > max ? s.substring(0, max - 3) + "..." : s;
    }

    private String randomPersonality() {
        String[] p = {"analytical", "optimistic", "skeptical", "pragmatic", "empathetic", "contrarian"};
        return p[rng.nextInt(p.length)];
    }
}
