package com.mirofish.service;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@Service
public class FileService {

    private static final Logger log = LoggerFactory.getLogger(FileService.class);

    public String extractText(MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) return "";
        String name = file.getOriginalFilename() != null
                ? file.getOriginalFilename().toLowerCase() : "";

        if (name.endsWith(".pdf")) {
            return extractPdf(file);
        }
        // txt, md, or anything else — treat as UTF-8 text
        return new String(file.getBytes(), StandardCharsets.UTF_8);
    }

    private String extractPdf(MultipartFile file) throws IOException {
        //try (PDDocument doc = PDDocument.load(file.getInputStream())) {
        try (PDDocument doc = Loader.loadPDF(file.getBytes())) {
            PDFTextStripper stripper = new PDFTextStripper();
            String text = stripper.getText(doc);
            log.info("Extracted {} chars from PDF '{}'", text.length(), file.getOriginalFilename());
            return text;
        }
    }
}
