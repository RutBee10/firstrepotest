package com.mirofish.service;

import com.mirofish.model.*;
import com.mirofish.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChatService {

    @Autowired private SimulationRepository   simRepo;
    @Autowired private AgentRepository        agentRepo;
    @Autowired private ChatMessageRepository  chatRepo;
    @Autowired private LlmService             llm;

    /** Chat with a specific agent (stays in character) */
    public String chatWithAgent(Long simId, Long agentId, String userMessage) {
        Simulation sim   = simRepo.findById(simId).orElseThrow();
        Agent      agent = agentRepo.findById(agentId).orElseThrow();

        persist(sim, agentId, "USER", userMessage);
        String reply = llm.chatAsAgent(
            agent.getName(), agent.getPersonality(), agent.getBackground(),
            agent.getCurrentOpinion(), sim.getPredictionQuery(), userMessage
        );
        persist(sim, agentId, "ASSISTANT", reply);
        return reply;
    }

    /** Chat with the ReportAgent (has full report as context) */
    public String chatWithReportAgent(Long simId, String userMessage) {
        Simulation sim = simRepo.findById(simId).orElseThrow();

        persist(sim, null, "USER", userMessage);
        String reply = llm.chatAsReportAgent(
            sim.getPredictionQuery(), sim.getReportMarkdown(), userMessage
        );
        persist(sim, null, "ASSISTANT", reply);
        return reply;
    }

    /** Retrieve chat history for sidebar display */
    public List<ChatMessage> getHistory(Long simId, Long agentId) {
        Simulation sim = simRepo.findById(simId).orElseThrow();
        return chatRepo.findBySimulationAndAgentIdOrderByCreatedAtAsc(sim, agentId);
    }

    private void persist(Simulation sim, Long agentId, String role, String content) {
        ChatMessage msg = new ChatMessage();
        msg.setSimulation(sim);
        msg.setAgentId(agentId);
        msg.setRole(role);
        msg.setContent(content);
        chatRepo.save(msg);
    }
}
