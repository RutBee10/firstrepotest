package com.mirofish.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mirofish.config.LlmConfig;
import okhttp3.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Central LLM gateway — wraps any OpenAI-compatible API.
 * Falls back to rich demo responses if no API key is configured.
 */
@Service
public class LlmService {

    private static final Logger log = LoggerFactory.getLogger(LlmService.class);
    private static final MediaType JSON_MEDIA = MediaType.get("application/json; charset=utf-8");

    @Autowired private LlmConfig llmConfig;
    @Autowired private OkHttpClient http;

    private final ObjectMapper mapper = new ObjectMapper();
    private final Random rng = new Random();

    // ─────────────────────────────────────────────────────────────────────────
    //  Core chat method
    // ─────────────────────────────────────────────────────────────────────────

    public String chat(String system, String user) {
        if (llmConfig.isDemoMode()) {
            return demoRoute(system, user);
        }
        try {
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("model", llmConfig.getModelName());
            body.put("max_tokens", 2048);
            body.put("temperature", 0.8);

            List<Map<String, String>> messages = new ArrayList<>();
            if (system != null && !system.isBlank()) {
                messages.add(Map.of("role", "system", "content", system));
            }
            messages.add(Map.of("role", "user", "content", user));
            body.put("messages", messages);

            Request req = new Request.Builder()
                    .url(llmConfig.getBaseUrl() + "/chat/completions")
                    .addHeader("Authorization", "Bearer " + llmConfig.getApiKey())
                    .addHeader("Content-Type", "application/json")
                    .post(RequestBody.create(mapper.writeValueAsString(body), JSON_MEDIA))
                    .build();

            try (Response resp = http.newCall(req).execute()) {
                if (!resp.isSuccessful()) {
                    log.warn("LLM API returned {}: {}", resp.code(), resp.message());
                    return demoRoute(system, user);
                }
                JsonNode root = mapper.readTree(resp.body().string());
                return root.path("choices").get(0).path("message").path("content").asText();
            }
        } catch (Exception e) {
            log.warn("LLM call failed ({}), using demo mode", e.getMessage());
            return demoRoute(system, user);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Domain-specific LLM operations (called by SimulationService)
    // ─────────────────────────────────────────────────────────────────────────

    /** Stage 1: Extract knowledge graph from seed text */
    public String extractKnowledgeGraph(String seedText) {
        String truncated = seedText.length() > 4000 ? seedText.substring(0, 4000) : seedText;
        return chat(
            "You are a knowledge graph extractor. Return ONLY valid JSON, no markdown fences.",
            "Extract entities and relationships from the following text.\n" +
            "Return a JSON object with exactly two keys:\n" +
            "  'entities': array of {\"name\":string, \"type\":string, \"description\":string}\n" +
            "  'relationships': array of {\"from\":string, \"to\":string, \"relation\":string}\n\n" +
            "TEXT:\n" + truncated
        );
    }

    /** Stage 2: Generate one agent persona */
    public String generatePersona(String topic, String kgSummary, int index, int total) {
        return chat(
            "You are an agent persona designer for social simulations. Return ONLY valid JSON.",
            String.format(
                "Design persona #%d of %d for a simulation about: \"%s\".\n" +
                "Context from knowledge graph: %s\n\n" +
                "Return JSON with keys:\n" +
                "  name (string), background (1-2 sentence career/personal context),\n" +
                "  personality (single adjective: analytical/optimistic/skeptical/pragmatic/idealistic/contrarian/empathetic/ambitious),\n" +
                "  initialOpinion (one sentence stance on the topic),\n" +
                "  platform (exactly TWITTER or REDDIT)\n" +
                "Make personas diverse — vary backgrounds, ages, perspectives, and viewpoints.",
                index, total, topic, kgSummary
            )
        );
    }

    /** Stage 3: Generate a social media post for one agent in one round */
    public String generatePost(String agentName, String personality, String currentOpinion,
                               String platform, String topic, String recentContext, int round) {
        boolean isTwitter = "TWITTER".equals(platform);
        return chat(
            "You are roleplaying as a " + platform + " user. Write only the post text — no quotes, no labels.",
            String.format(
                "You are %s (%s personality). Your current opinion: \"%s\".\n" +
                "Topic: \"%s\" | Round %d of the simulation.\n\n" +
                "Recent discussion context:\n%s\n\n" +
                "%s",
                agentName, personality, currentOpinion, topic, round,
                recentContext.length() > 800 ? recentContext.substring(recentContext.length() - 800) : recentContext,
                isTwitter
                    ? "Write a tweet (max 280 characters). Be direct, conversational, possibly use hashtags."
                    : "Write a Reddit-style comment (2-4 sentences). Be more detailed and analytical."
            )
        );
    }

    /** Stage 3: Update an agent's opinion based on what they've seen */
    public String updateOpinion(String agentName, String currentOpinion,
                                String recentPosts, String topic) {
        return chat(
            "You model how social media users update their beliefs. Return ONLY valid JSON.",
            String.format(
                "Agent '%s' currently believes: \"%s\".\n" +
                "After reading these posts about '%s':\n%s\n\n" +
                "Return JSON: {\"updatedOpinion\": \"<new 1-sentence stance>\", \"shift\": <0.0 to 1.0>}\n" +
                "shift=0.0 means no change, shift=1.0 means complete reversal.",
                agentName, currentOpinion, topic,
                recentPosts.length() > 1200 ? recentPosts.substring(recentPosts.length() - 1200) : recentPosts
            )
        );
    }

    /** Stage 4: Synthesize the final prediction report */
    public String generateReport(String topic, String agentChanges, String activityLog, String kgJson) {
        return chat(
            "You are a senior analyst generating a structured prediction report from a multi-agent swarm simulation. Be insightful, specific, and data-driven.",
            String.format(
                "PREDICTION QUESTION: %s\n\n" +
                "AGENT OPINION EVOLUTION:\n%s\n\n" +
                "SIMULATION ACTIVITY SAMPLE:\n%s\n\n" +
                "Generate a comprehensive Markdown report with these exact sections:\n" +
                "## Executive Summary\n" +
                "## Key Prediction\n" +
                "## Dominant Narratives\n" +
                "## Opinion Dynamics & Polarization\n" +
                "## Influential Voices & Coalitions\n" +
                "## Confidence Level & Caveats\n" +
                "## Recommended Actions\n\n" +
                "Be specific about what the simulation revealed. Include concrete insights.",
                topic, agentChanges, activityLog.substring(0, Math.min(3000, activityLog.length()))
            )
        );
    }

    /** Stage 5: Chat with a specific agent in-character */
    public String chatAsAgent(String agentName, String personality, String background,
                              String currentOpinion, String topic, String userQuestion) {
        return chat(
            String.format(
                "You ARE %s — %s. You have a %s personality.\n" +
                "You participated in a simulation about: \"%s\".\n" +
                "Your current view: \"%s\".\n" +
                "Stay fully in character. Be opinionated, authentic, and human.",
                agentName, background, personality, topic, currentOpinion
            ),
            userQuestion
        );
    }

    /** Stage 5: Chat with the ReportAgent */
    public String chatAsReportAgent(String topic, String report, String userQuestion) {
        return chat(
            String.format(
                "You are the MiroFish ReportAgent — an expert analyst who orchestrated a " +
                "multi-agent simulation about: \"%s\".\n\n" +
                "SIMULATION REPORT:\n%s",
                topic,
                report != null ? report.substring(0, Math.min(5000, report.length())) : "Report not yet available."
            ),
            userQuestion
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    //  Demo mode — rich, realistic fallback responses
    // ─────────────────────────────────────────────────────────────────────────

    private String demoRoute(String system, String user) {
        String combined = ((system != null ? system : "") + " " + user).toLowerCase();
        if (combined.contains("persona") || combined.contains("agent") && combined.contains("design")) return demoPersona();
        if (combined.contains("knowledge graph") || combined.contains("entities")) return demoKnowledgeGraph();
        if (combined.contains("report") || combined.contains("prediction question")) return demoReport();
        if (combined.contains("updatedbopinion") || combined.contains("shift")) return demoOpinionUpdate();
        if (combined.contains("tweet") || combined.contains("reddit") || combined.contains("post")) return demoPost();
        return "I've reviewed the information and have a nuanced perspective on this. [Demo mode — configure llm.api-key in application.properties for real AI responses]";
    }

    private String demoPersona() {
        String[][] personas = {
            {"Dr. Amira Hassan", "Senior economist at an international policy institute with 18 years studying emerging markets.", "analytical", "The data points to a more complex outcome than the headlines suggest — we need to look at second-order effects.", "TWITTER"},
            {"Marco Bellini", "Entrepreneur who built and sold two fintech startups; angel investor in 30+ companies.", "optimistic", "This is a massive inflection point. Early movers will define the next decade.", "REDDIT"},
            {"Sarah Okonkwo", "Investigative journalist covering tech and society for a major newspaper for 12 years.", "skeptical", "I need to see the evidence beyond the press releases before drawing conclusions.", "TWITTER"},
            {"James Thornton", "Community organizer and policy advocate focused on economic equity in underserved regions.", "empathetic", "The question isn't just what will happen, but who bears the cost and who reaps the benefit.", "REDDIT"},
            {"Dr. Liu Wei", "Computational social scientist studying how information spreads through networked populations.", "analytical", "The network topology here suggests a cascade pattern — small shifts can have outsized effects.", "TWITTER"},
            {"Priya Mehta", "Chief Strategy Officer at a Fortune 500 company navigating digital transformation.", "pragmatic", "Regardless of the long-term picture, we need to make decisions in the next 90 days.", "REDDIT"},
            {"Yusuf Al-Rashid", "Policy researcher at a think tank specializing in geopolitical risk and technology governance.", "contrarian", "The mainstream view is missing a critical structural factor that changes the calculus entirely.", "TWITTER"},
            {"Elena Vasquez", "Climate scientist and science communicator with a large public following.", "idealistic", "We should be asking whether this is the world we want to create, not just what is likely to happen.", "REDDIT"},
        };
        String[] p = personas[rng.nextInt(personas.length)];
        return String.format("{\"name\":\"%s\",\"background\":\"%s\",\"personality\":\"%s\",\"initialOpinion\":\"%s\",\"platform\":\"%s\"}",
            p[0], p[1], p[2], p[3], p[4]);
    }

    private String demoKnowledgeGraph() {
        return "{\"entities\":[" +
            "{\"name\":\"Key Policy\",\"type\":\"Concept\",\"description\":\"Central regulatory framework under discussion\"}," +
            "{\"name\":\"Government Bodies\",\"type\":\"Organization\",\"description\":\"National and international regulatory authorities\"}," +
            "{\"name\":\"Industry Players\",\"type\":\"Group\",\"description\":\"Companies and stakeholders with economic stakes\"}," +
            "{\"name\":\"Public Opinion\",\"type\":\"Concept\",\"description\":\"Collective sentiment of the general population\"}," +
            "{\"name\":\"Economic Impact\",\"type\":\"Concept\",\"description\":\"Financial and market consequences of decisions\"}," +
            "{\"name\":\"Technology\",\"type\":\"Enabler\",\"description\":\"Technical systems enabling or disrupting the landscape\"}," +
            "{\"name\":\"Media\",\"type\":\"Institution\",\"description\":\"News and social media shaping narrative\"}]," +
            "\"relationships\":[" +
            "{\"from\":\"Government Bodies\",\"to\":\"Key Policy\",\"relation\":\"formulates\"}," +
            "{\"from\":\"Key Policy\",\"to\":\"Economic Impact\",\"relation\":\"drives\"}," +
            "{\"from\":\"Industry Players\",\"to\":\"Key Policy\",\"relation\":\"lobbies for\"}," +
            "{\"from\":\"Media\",\"to\":\"Public Opinion\",\"relation\":\"shapes\"}," +
            "{\"from\":\"Public Opinion\",\"to\":\"Government Bodies\",\"relation\":\"pressures\"}," +
            "{\"from\":\"Technology\",\"to\":\"Economic Impact\",\"relation\":\"amplifies\"}]}";
    }

    private String demoPost() {
        String[] posts = {
            "The data on this is clearer than most people realize. Three structural factors that aren't getting enough attention: timing, incentive alignment, and who controls the narrative.",
            "Hot take: everyone's focused on the first-order effects but the second and third-order consequences are where the real story is. History is very instructive here.",
            "Talked to a dozen people working on this directly last week. The reality on the ground is meaningfully different from the public picture. Pattern recognition matters.",
            "The coalition forming around this position is broader and more durable than critics assume. When you see this level of cross-partisan alignment, it usually signals something significant.",
            "I've been tracking the leading indicators for 6 months. The signal-to-noise ratio is improving and it's pointing in one direction. Conviction is building.",
            "Counterpoint to the optimists: the adoption curve has structural friction that the models aren't adequately pricing in. We've seen this movie before.",
            "What strikes me about this debate is how much of it is actually a proxy for deeper disagreements about values and who gets to decide. The technical question is almost secondary.",
            "Three data points I'm watching: regulatory posture shift, capital flow direction, and talent migration. Right now two of three are moving the same way.",
            "The polarization in this discussion is itself informative. High disagreement early in a trend often precedes rapid consensus formation — we may be closer to resolution than it looks.",
            "Genuine question: are we anchoring too heavily on recent precedent? The structural conditions today differ from historical analogues in ways that matter for the prediction.",
        };
        return posts[rng.nextInt(posts.length)];
    }

    private String demoOpinionUpdate() {
        String[] updates = {
            "{\"updatedOpinion\":\"After considering multiple perspectives in this discussion, I'm updating toward a more cautious middle ground — the evidence is more mixed than I initially thought.\",\"shift\":0.35}",
            "{\"updatedOpinion\":\"The counter-arguments I've encountered are compelling. I'm moderating my initial position while maintaining core skepticism.\",\"shift\":0.4}",
            "{\"updatedOpinion\":\"My initial view is holding up well against scrutiny. If anything, the pushback has clarified why I hold this position.\",\"shift\":0.05}",
            "{\"updatedOpinion\":\"I'm becoming more convinced of my original stance — the data being cited by the other side has significant methodological issues.\",\"shift\":0.1}",
            "{\"updatedOpinion\":\"A genuinely novel argument has shifted my thinking. I now see the complexity I was underweighting before.\",\"shift\":0.55}",
        };
        return updates[rng.nextInt(updates.length)];
    }

    private String demoReport() {
        return "## Executive Summary\n\n" +
            "The multi-agent simulation involving diverse AI agents across simulated Twitter and Reddit environments " +
            "reveals a complex, non-linear trajectory for the scenario under examination. Emergent consensus began " +
            "forming around round 6-7, with two dominant coalitions crystallizing from an initially fragmented opinion landscape.\n\n" +
            "## Key Prediction\n\n" +
            "**Most likely outcome (62% agent convergence):** A moderate, gradualist trajectory with significant " +
            "minority dissent sustained throughout. Change will be slower than optimists project and more durable " +
            "than pessimists fear. Expect 18-24 months before clear directional signal emerges.\n\n" +
            "**Key trigger to watch:** Coalition-bridging events — moments when normally opposed factions find " +
            "common ground — which historically precede rapid phase transitions.\n\n" +
            "## Dominant Narratives\n\n" +
            "**Narrative A — Pragmatic Adaptation (45% of agents):** Focused on incremental adaptation, risk " +
            "management, and preserving optionality. This coalition showed high internal coherence.\n\n" +
            "**Narrative B — Transformative Disruption (38% of agents):** Emphasized fundamental change and " +
            "first-mover advantage. High enthusiasm but lower consensus on mechanism.\n\n" +
            "**Narrative C — Structural Skepticism (17% of agents):** Questioned core assumptions. Small but " +
            "intellectually influential — disproportionately shifted the debate toward nuance.\n\n" +
            "## Opinion Dynamics & Polarization\n\n" +
            "Polarization index peaked at 0.74 in round 5 before declining to 0.52 by round 10, suggesting " +
            "natural moderation dynamics. Agents with analytical personalities showed the most opinion mobility " +
            "(avg shift: 0.42); contrarian personalities showed least (avg: 0.11).\n\n" +
            "Information cascades were detected in rounds 3, 6, and 9 — high-influence agents triggered " +
            "measurable opinion shifts in connected nodes within 1-2 rounds.\n\n" +
            "## Influential Voices & Coalitions\n\n" +
            "Top-influencing agents (by post engagement and opinion-shift causation) shared three traits: " +
            "analytical personality type, early-round participation, and cross-platform presence. " +
            "Coalition formation was primarily platform-specific, with limited Twitter-Reddit cross-pollination.\n\n" +
            "## Confidence Level & Caveats\n\n" +
            "**Confidence: Moderate (65%)** — based on 20 agents over 10 simulation rounds.\n\n" +
            "Key caveats: LLM agents tend to exhibit faster opinion convergence than real humans; emotional " +
            "contagion effects are underrepresented; wildcard exogenous events not modeled. " +
            "Increase agent count to 40+ and rounds to 20+ for higher confidence.\n\n" +
            "## Recommended Actions\n\n" +
            "1. **Monitor leading indicators:** Pay attention to coalition-bridging events as early signals of phase transition\n" +
            "2. **Re-run with updated seed data** as the situation evolves — monthly refresh recommended\n" +
            "3. **Stress-test with adversarial scenarios** — inject disruptive events to test resilience of predictions\n" +
            "4. **Increase simulation depth** — 40 agents × 20 rounds for production-grade predictions\n" +
            "5. **Track the 17% skeptics** — minority positions with structural arguments often foreshadow mainstream shifts\n\n" +
            "*[Demo Mode Report — configure llm.api-key for AI-generated analysis]*";
    }
}
