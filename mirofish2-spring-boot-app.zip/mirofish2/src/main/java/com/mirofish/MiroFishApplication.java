package com.mirofish;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * MiroFish — Multi-Agent AI Prediction Engine
 *
 * A swarm-intelligence engine that predicts future trends by simulating
 * thousands of AI agents with unique personalities, memories, and opinions
 * interacting in a digital sandbox — mirroring real social dynamics.
 *
 * Pipeline: Seed → Knowledge Graph → Agent Creation → Dual-Platform Simulation
 *           → Report Generation → Deep Interaction
 */
@SpringBootApplication
@EnableAsync
public class MiroFishApplication {
    public static void main(String[] args) {
        SpringApplication.run(MiroFishApplication.class, args);
        System.out.println("""
            ╔══════════════════════════════════════════════════════╗
            ║      🐟 MiroFish — Swarm Intelligence Engine         ║
            ║      Multi-Agent AI Prediction Engine                ║
            ║      Running at: http://localhost:9090               ║
            ╚══════════════════════════════════════════════════════╝
            """);
    }
}
