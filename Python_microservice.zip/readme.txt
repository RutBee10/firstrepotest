- Save the Python script as app.py.
- Install dependencies:
pip install flask requests openai
pip install flask-cors
- Run the microservice:
python app.py
- Open index.html in your browser.
- Type a message, choose Ollama or OpenAI, and hit Send.


====

create python base microservice that works with local ollama chat api and OpenAi chat api and UI page in html to interact with the microservice api. UI has input text area with submit form and output text area to display result from llm. Disable SSL for local llm api calls from python script
