from flask import Flask, request, jsonify
import requests
import openai
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

openai.api_key = "YOUR_OPENAI_API_KEY"

OLLAMA_API_URL = "http://127.0.0.1:11434/api/chat"


@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_input = data.get("message", "")
    provider = data.get("provider", "ollama")

    if provider == "ollama":
        try:
            response = requests.post(
                OLLAMA_API_URL,
                json={
                    "model": "llama3.2",
                    "messages": [{"role": "user", "content": user_input}],
                    "stream": False,        # ← key fix: tell Ollama not to stream
                },
            )
            response.raise_for_status()
            result = response.json()

            # result["message"] is {"role": "assistant", "content": "..."}
            message = result.get("message", {})
            reply = (
                message.get("content", "No response from Ollama")
                if isinstance(message, dict)
                else str(message)
            )
            return jsonify({"reply": reply})

        except requests.exceptions.RequestException as e:
            return jsonify({"error": f"Ollama request failed: {str(e)}"}), 500
        except ValueError as e:
            return jsonify({"error": f"Failed to parse Ollama response: {str(e)}"}), 500
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    elif provider == "openai":
        try:
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[{"role": "user", "content": user_input}],
            )
            reply = response.choices[0].message["content"]
            return jsonify({"reply": reply})

        except openai.error.AuthenticationError:
            return jsonify({"error": "Invalid OpenAI API key"}), 401
        except openai.error.RateLimitError:
            return jsonify({"error": "OpenAI rate limit exceeded"}), 429
        except openai.error.OpenAIError as e:
            return jsonify({"error": f"OpenAI error: {str(e)}"}), 500
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    return jsonify({"error": "Invalid provider. Use 'ollama' or 'openai'"}), 400


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)