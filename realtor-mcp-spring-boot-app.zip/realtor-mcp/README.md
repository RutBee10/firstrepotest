# Realtor.ca MCP Server — Spring Boot + Multi-Provider LLM

Java Spring Boot implementation of the [realtor-mcp](https://github.com/sanchorelaxo/realtor-mcp) Python server,
with a full MCP JSON-RPC 2.0 server, web chat UI, and support for **5 LLM providers** switchable via config.

## Features

- 🍁 Live property search from **realtor.ca** (Canadian real estate)
- 🔧 Two MCP tools: `search_properties` + `advanced_search` (faithful port of Python server.py)
- 🤖 **5 LLM providers**: Anthropic, Ollama, Gemini, Perplexity, Copilot/OpenAI/Azure
- 🌐 Web chat UI with provider switcher, model selector, JSON viewer, CSV/JSON export
- 📡 Full MCP JSON-RPC 2.0 server endpoint (`/mcp/jsonrpc`)
- 💾 Auto-export results as JSON + CSV

## Supported LLM Providers

| Provider       | Config value  | Env var             |
|----------------|---------------|---------------------|
| Anthropic Claude | `anthropic` | `ANTHROPIC_API_KEY` |
| Ollama (local) | `ollama`      | none                |
| Google Gemini  | `gemini`      | `GEMINI_API_KEY`    |
| Perplexity AI  | `perplexity`  | `PERPLEXITY_API_KEY`|
| Copilot / OpenAI / Azure | `copilot` | `OPENAI_API_KEY` |

## Quick Start

### 1. Set API key

```bash
export ANTHROPIC_API_KEY=sk-ant-your-key
# or for other providers:
export GEMINI_API_KEY=AIza...
export PERPLEXITY_API_KEY=pplx-...
export OPENAI_API_KEY=sk-...
```

### 2. Choose provider in `application.properties`

```properties
llm.active-provider=anthropic   # anthropic | ollama | gemini | perplexity | copilot
```

### 3. Run

```bash
./gradlew bootRun
```

### 4. Open UI

```
http://localhost:8080
```

## Example Queries

- `Find houses for sale in Toronto, Ontario between $700,000 and $1,200,000`
- `Search condos in Vancouver, BC under $800,000`
- `Find rentals in Montreal, Quebec under $2,500/month`
- `Advanced search: 3+ bedroom houses in Calgary with garage, newest first`
- `Waterfront properties in Ottawa, Ontario`
- `Commercial properties in Mississauga under $2 million`
- `Condos with pool in Edmonton, Alberta $300K–$600K`

## MCP Tools

### `search_properties`
Simple search by city, province, price range and transaction type.

Parameters: `city` (required), `province` (required), `min_price`, `max_price`, `transaction_type` (for_sale/for_rent), `max_results`

### `advanced_search`
Full realtor.ca API parameter control.

Parameters include all of the above plus:
- `property_type_id`: 1=Residential 2=Recreational 3=Commercial 4=Agricultural 5=Parking 6=Vacant Land
- `building_type_id`: 1=House 2=Duplex 3=Triplex 16=Townhouse 17=Apartment 19=Fourplex 20=Garden Home
- `ownership_type_id`: 1=Freehold 2=Condo/Strata 3=Timeshare 4=Leasehold
- `min/max_bedrooms`, `min/max_bathrooms`, `min/max_square_feet`
- `min/max_parking`, `min/max_storeys`
- `air_conditioning`, `pool`, `fireplace`, `garage` (boolean)
- `keywords` (e.g. "waterfront", "downtown", "renovated")
- `open_house`, `number_of_days`
- `sort_order`: 1-A=price asc, 1-D=price desc, 6-D=date desc, 11-D=newest
- `current_page`

## Province Codes

ON=Ontario · BC=British Columbia · QC=Quebec · AB=Alberta · MB=Manitoba
SK=Saskatchewan · NS=Nova Scotia · NB=New Brunswick · NL=Newfoundland
PE=Prince Edward Island · NT=Northwest Territories · YT=Yukon · NU=Nunavut

## Endpoints

| Endpoint | Description |
|---|---|
| `GET /` | Web chat UI |
| `POST /mcp/jsonrpc` | MCP JSON-RPC 2.0 |
| `GET /mcp/health` | Health check |
| `GET /mcp/tools` | List tools (REST) |
| `POST /mcp/tools/{name}` | Invoke tool directly |
| `POST /api/chat` | Chat API |
| `GET /api/files` | List exported files |
| `GET /api/files/download?path=…` | Download JSON/CSV |

## MCP Client Config (Claude Desktop)

```json
{
  "mcpServers": {
    "realtor-ca": {
      "command": "curl",
      "args": ["-s", "-X", "POST", "http://localhost:8080/mcp/jsonrpc",
               "-H", "Content-Type: application/json", "-d", "@-"]
    }
  }
}
```

Or use the HTTP transport directly at `http://localhost:8080/mcp/jsonrpc`.

## Architecture

```
src/main/java/com/realtor/mcp/
├── RealtorMcpApplication.java
├── config/JacksonConfig.java
├── llm/
│   ├── LlmClient.java              ← Provider interface
│   ├── LlmProvider.java            ← ANTHROPIC|OLLAMA|GEMINI|PERPLEXITY|COPILOT
│   ├── LlmConfig.java              ← @ConfigurationProperties
│   ├── LlmRequest.java / LlmResponse.java
│   ├── LlmClientFactory.java       ← Active client resolver
│   ├── AnthropicLlmClient.java
│   ├── OpenAiCompatibleClient.java ← Base for Ollama/Perplexity/Copilot
│   ├── OllamaLlmClient.java
│   ├── PerplexityLlmClient.java
│   ├── GeminiLlmClient.java
│   └── CopilotLlmClient.java
├── service/
│   ├── RealtorCaApiService.java    ← Java port of Python server.py
│   ├── McpToolService.java         ← Tool registry & dispatch
│   ├── LlmService.java             ← Agentic loop
│   └── FileExportService.java      ← JSON + CSV export
├── controller/
│   ├── ChatController.java         ← Web UI + REST API
│   └── McpServerController.java    ← MCP JSON-RPC 2.0 server
└── model/
    └── Property, SearchRequest, SearchResult, ChatRequest/Response, Mcp*
```

## Notes

- Realtor.ca API may rate-limit or block IPs — wait briefly between heavy usage
- Geographic search uses ~50km bounding box around city center (Nominatim geocoding)
- Maximum 200 results per request (API limit)
- No realtor.ca API key required (public API)

## Credits

Based on [realtor-mcp](https://github.com/sanchorelaxo/realtor-mcp) Python server.
Built with Spring Boot 3.2, Java 17, Gradle.
