package com.realtor.mcp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;

@SpringBootTest
@TestPropertySource(properties = {
    "llm.anthropic.api-key=test-key",
    "llm.gemini.api-key=test-key",
    "llm.perplexity.api-key=test-key",
    "llm.copilot.api-key=test-key"
})
class RealtorMcpApplicationTests {
    @Test
    void contextLoads() {}
}
