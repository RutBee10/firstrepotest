package com.realtor.mcp.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.realtor.mcp.llm.*;
import com.realtor.mcp.model.ChatRequest;
import com.realtor.mcp.model.ChatResponse;
import com.realtor.mcp.model.McpTool;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Slf4j @Service @RequiredArgsConstructor
public class LlmService {

    private final LlmClientFactory clientFactory;
    private final McpToolService mcpToolService;
    private final FileExportService fileExportService;
    private final ObjectMapper objectMapper;

    public ChatResponse chat(ChatRequest request) {
        LlmClient client = clientFactory.activeClient();
        String model = (request.getModel() != null && !request.getModel().isBlank())
                ? request.getModel() : clientFactory.defaultModel();

        log.info("Chat via provider={} model={}", client.provider(), model);

        try {
            List<McpTool> tools = mcpToolService.listTools();
            List<Map<String, Object>> toolDefs = clientFactory.buildToolDefs(tools);

            List<Map<String, Object>> messages = new ArrayList<>();
            messages.add(Map.of("role","user","content", request.getMessage()));

            List<ChatResponse.ToolCall> toolCallLog = new ArrayList<>();
            Object finalJsonData = null;
            String assistantText = "";

            // Agentic loop
            for (int i = 0; i < 1; i++) {
                LlmResponse resp = client.chat(LlmRequest.builder()
                        .model(model).systemPrompt(systemPrompt())
                        .messages(messages).tools(toolDefs)
                        .maxTokens(request.getMaxTokens() != null ? request.getMaxTokens() : 4096)
                        .build());

                if (!resp.isSuccess())
                    return ChatResponse.builder().success(false).error(resp.getErrorMessage())
                            .timestamp(LocalDateTime.now()).model(model).build();

                if (resp.getText() != null && !resp.getText().isBlank()) assistantText = resp.getText();

                boolean hasTools = resp.getToolUses() != null && !resp.getToolUses().isEmpty();
                if (!hasTools) {
                    messages.add(Map.of("role","assistant","content",
                            assistantText.isBlank() ? "Done." : assistantText));
                    break;
                }

                List<Map<String, Object>> assistantRaw = buildAssistantRaw(client.provider(), assistantText, resp.getToolUses());
                List<LlmClient.ToolResult> toolResults = new ArrayList<>();

                for (LlmResponse.ToolUse tu : resp.getToolUses()) {
                    log.info("Executing tool: {} args: {}", tu.getName(), tu.getArguments());
                    Object result = mcpToolService.callTool(tu.getName(), tu.getArguments());
                    log.info("result>>>>>>>>>>>>>>>>>>>>"+result);
                    finalJsonData = result;
                    toolCallLog.add(ChatResponse.ToolCall.builder()
                            .toolName(tu.getName()).input(tu.getArguments()).result(result).build());
                    String resultJson = objectMapper.writeValueAsString(result != null ? result : "null");
                    toolResults.add(new LlmClient.ToolResult(tu.getId(), tu.getName(), resultJson));
                }

                messages = client.appendToolResult(messages, assistantRaw, toolResults);
            }

            String convId = UUID.randomUUID().toString().substring(0,8).toUpperCase();
            String jsonPath = null, csvPath = null;
            if (finalJsonData != null) {
                jsonPath = fileExportService.exportToJson(finalJsonData, convId);
                csvPath  = fileExportService.exportToCsv(finalJsonData, convId);
            }

            return ChatResponse.builder()
                    .conversationId(convId).message(assistantText).model(model)
                    .timestamp(LocalDateTime.now()).jsonData(finalJsonData)
                    .jsonFilePath(jsonPath).csvFilePath(csvPath)
                    .toolCalls(toolCallLog).success(true).build();

        } catch (Exception e) {
            log.error("LLM error", e);
            return ChatResponse.builder().success(false).error("Error: " + e.getMessage())
                    .timestamp(LocalDateTime.now()).model(model).build();
        }
    }

    private String systemPrompt() {
        return """
                You are a helpful Canadian real estate assistant powered by the Realtor.ca MCP Server.
                You search live property listings directly from realtor.ca for cities across Canada.
                
                Use search_properties for simple searches by city, province and price range.
                Use advanced_search when users want to filter by:
                  - property/building type (house, condo, commercial, etc.)
                  - bedrooms, bathrooms, square footage, parking
                  - amenities: garage, pool, fireplace, air conditioning
                  - keywords (waterfront, renovated, etc.)
                  - listing age (number_of_days), open house, sort order
                
                Province codes: ON=Ontario BC=British Columbia QC=Quebec AB=Alberta MB=Manitoba
                  SK=Saskatchewan NS=Nova Scotia NB=New Brunswick NL=Newfoundland PE=PEI NT NL YT NU
                
                Prices are in Canadian dollars (CAD). Always mention the city and province searched.
                If a search returns 0 results, suggest broadening the criteria.
                All results are automatically saved as JSON and CSV files.
                """;
    }

    private List<Map<String, Object>> buildAssistantRaw(LlmProvider provider, String text, List<LlmResponse.ToolUse> toolUses) {
        List<Map<String, Object>> parts = new ArrayList<>();
        if (provider == LlmProvider.ANTHROPIC) {
            if (!text.isBlank()) parts.add(Map.of("type","text","text",text));
            for (var tu : toolUses)
                parts.add(Map.of("type","tool_use","id",tu.getId(),"name",tu.getName(),"input",tu.getArguments()));
        } else if (provider == LlmProvider.GEMINI) {
            for (var tu : toolUses)
                parts.add(Map.of("type","tool_use","name",tu.getName(),"input",tu.getArguments()));
        } else {
            // OpenAI-compatible
            List<Map<String, Object>> toolCalls = new ArrayList<>();
            for (var tu : toolUses) {
                String argsJson;
                try { argsJson = objectMapper.writeValueAsString(tu.getArguments()); } catch (Exception e) { argsJson = "{}"; }
                toolCalls.add(Map.of("id",tu.getId(),"type","function","function",Map.of("name",tu.getName(),"arguments",argsJson)));
            }
            parts.add(Map.of("role","assistant","content",text,"tool_calls",toolCalls));
        }
        return parts;
    }
}
