package com.realtor.mcp.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.realtor.mcp.model.McpTool;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;

@Slf4j @Component @RequiredArgsConstructor
public class AnthropicLlmClient implements LlmClient {

    private final LlmConfig config;
    private final ObjectMapper objectMapper;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(30)).build();

    @Override public LlmProvider provider() { return LlmProvider.ANTHROPIC; }

    @Override
    public LlmResponse chat(LlmRequest req) {
        try {
            var p = config.getAnthropic();
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("model", req.getModel());
            body.put("max_tokens", req.getMaxTokens() != null ? req.getMaxTokens() : 4096);
            if (req.getSystemPrompt() != null) body.put("system", req.getSystemPrompt());
            body.put("messages", req.getMessages());
            if (req.getTools() != null && !req.getTools().isEmpty()) body.put("tools", req.getTools());

            HttpRequest httpReq = HttpRequest.newBuilder()
                    .uri(URI.create(p.getApiUrl()))
                    .header("Content-Type","application/json")
                    .header("x-api-key", p.getApiKey())
                    .header("anthropic-version", p.getApiVersion())
                    .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(body)))
                    .timeout(Duration.ofSeconds(120)).build();

            HttpResponse<String> resp = http.send(httpReq, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200)
                return LlmResponse.builder().success(false)
                        .errorMessage("HTTP " + resp.statusCode() + ": " + resp.body()).build();

            JsonNode root = objectMapper.readTree(resp.body());
            String stopReason = root.path("stop_reason").asText("end_turn");
            String text = "";
            List<LlmResponse.ToolUse> toolUses = new ArrayList<>();

            for (JsonNode block : root.path("content")) {
                if ("text".equals(block.path("type").asText())) {
                    text = block.path("text").asText();
                } else if ("tool_use".equals(block.path("type").asText())) {
                    toolUses.add(LlmResponse.ToolUse.builder()
                            .id(block.path("id").asText())
                            .name(block.path("name").asText())
                            .arguments(objectMapper.convertValue(block.path("input"), Map.class))
                            .build());
                }
            }
            return LlmResponse.builder().text(text).stopReason(stopReason).toolUses(toolUses).success(true).build();
        } catch (Exception e) {
            log.error("Anthropic error", e);
            return LlmResponse.builder().success(false).errorMessage(e.getMessage()).build();
        }
    }

    @Override
    public List<Map<String, Object>> appendToolResult(
            List<Map<String, Object>> messages, List<Map<String, Object>> assistantRaw, List<ToolResult> toolResults) {
        messages.add(Map.of("role","assistant","content",assistantRaw));
        List<Map<String, Object>> blocks = new ArrayList<>();
        for (ToolResult tr : toolResults)
            blocks.add(Map.of("type","tool_result","tool_use_id",tr.toolCallId(),"content",tr.resultJson()));
        messages.add(Map.of("role","user","content",blocks));
        return messages;
    }

    public static List<Map<String, Object>> buildToolDefs(List<McpTool> tools) {
        List<Map<String, Object>> result = new ArrayList<>();
        for (var t : tools)
            result.add(Map.of("name",t.getName(),"description",t.getDescription(),"input_schema",t.getInputSchema()));
        return result;
    }
}
