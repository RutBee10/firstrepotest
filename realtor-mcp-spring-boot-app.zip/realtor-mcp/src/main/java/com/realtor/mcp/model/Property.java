package com.realtor.mcp.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Property {

    @JsonProperty("mls_number")
    private String mlsNumber;

    private String price;

    private Address address;

    @JsonProperty("property_type")
    private String propertyType;

    private String bedrooms;
    private String bathrooms;

    @JsonProperty("square_feet")
    private String squareFeet;

    private String description;

    @JsonProperty("photo_url")
    private String photoUrl;

    @JsonProperty("listing_url")
    private String listingUrl;

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Address {
        private String street;
        private String city;
        private String province;
        @JsonProperty("postal_code")
        private String postalCode;
    }
}
