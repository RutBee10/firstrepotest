package com.realtor.mcp.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.realtor.mcp.model.McpTool;
import com.realtor.mcp.model.SearchRequest;
import com.realtor.mcp.model.SearchResult;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j @Service @RequiredArgsConstructor
public class McpToolService {

    private final RealtorCaApiService realtorApi;
    private final ObjectMapper objectMapper;

    // ─── Tool definitions ────────────────────────────────────────────────────

    public List<McpTool> listTools() {
        return List.of(buildSearchPropertiesTool(), buildAdvancedSearchTool());
    }

    private McpTool buildSearchPropertiesTool() {
        return McpTool.builder()
                .name("search_properties")
                .description("Search for properties on realtor.ca by city, province, and price range.")
                .inputSchema(Map.of(
                        "type", "object",
                        "properties", Map.of(
                                "city",             Map.of("type","string",  "description","City name (e.g. Toronto, Vancouver, Montreal)"),
                                "province",         Map.of("type","string",  "description","Province code (e.g. ON, BC, QC, AB)"),
                                "min_price",        Map.of("type","integer", "description","Minimum price in CAD"),
                                "max_price",        Map.of("type","integer", "description","Maximum price in CAD"),
                                "transaction_type", Map.of("type","string",  "description","for_sale or for_rent (default: for_sale)"),
                                "max_results",      Map.of("type","integer", "description","Max results to return (default 50, max 200)")
                        ),
                        "required", List.of("city","province")
                ))
                .build();
    }

    private McpTool buildAdvancedSearchTool() {
        Map<String, Object> props = new LinkedHashMap<>();
        props.put("city",                  Map.of("type","string",  "description","City name"));
        props.put("province",              Map.of("type","string",  "description","Province code (ON, BC, QC, AB, MB, SK, NS, NB, NL, PE, NT, YT, NU)"));
        props.put("min_price",             Map.of("type","integer", "description","Minimum price in CAD"));
        props.put("max_price",             Map.of("type","integer", "description","Maximum price in CAD"));
        props.put("transaction_type",      Map.of("type","string",  "description","for_sale or for_rent"));
        props.put("max_results",           Map.of("type","integer", "description","Max results (default 50, max 200)"));
        props.put("property_type_id",      Map.of("type","string",  "description","Property type: 1=Residential 2=Recreational 3=Commercial 4=Agricultural 5=Parking 6=Vacant Land"));
        props.put("building_type_id",      Map.of("type","string",  "description","Building type: 1=House 2=Duplex 3=Triplex 16=Townhouse 17=Apartment 19=Fourplex 20=Garden Home"));
        props.put("construction_style_id", Map.of("type","string",  "description","Construction style ID"));
        props.put("ownership_type_id",     Map.of("type","string",  "description","1=Freehold 2=Condo/Strata 3=Timeshare 4=Leasehold"));
        props.put("min_bedrooms",          Map.of("type","integer", "description","Minimum bedrooms"));
        props.put("max_bedrooms",          Map.of("type","integer", "description","Maximum bedrooms"));
        props.put("min_bathrooms",         Map.of("type","integer", "description","Minimum bathrooms"));
        props.put("max_bathrooms",         Map.of("type","integer", "description","Maximum bathrooms"));
        props.put("min_square_feet",       Map.of("type","integer", "description","Minimum interior square footage"));
        props.put("max_square_feet",       Map.of("type","integer", "description","Maximum interior square footage"));
        props.put("min_parking",           Map.of("type","integer", "description","Minimum parking spaces"));
        props.put("max_parking",           Map.of("type","integer", "description","Maximum parking spaces"));
        props.put("min_storeys",           Map.of("type","integer", "description","Minimum storeys"));
        props.put("max_storeys",           Map.of("type","integer", "description","Maximum storeys"));
        props.put("air_conditioning",      Map.of("type","boolean", "description","Must have A/C"));
        props.put("pool",                  Map.of("type","boolean", "description","Must have pool"));
        props.put("fireplace",             Map.of("type","boolean", "description","Must have fireplace"));
        props.put("garage",                Map.of("type","boolean", "description","Must have garage"));
        props.put("keywords",              Map.of("type","string",  "description","Keywords in description (e.g. waterfront lake renovated)"));
        props.put("open_house",            Map.of("type","boolean", "description","Has scheduled open house"));
        props.put("number_of_days",        Map.of("type","integer", "description","Listed within last X days"));
        props.put("sort_order",            Map.of("type","string",  "description","1-A=Price asc 1-D=Price desc 6-D=Date desc 11-D=Most recent 12-D=Open House"));
        props.put("current_page",          Map.of("type","integer", "description","Page number for pagination (default 1)"));

        return McpTool.builder()
                .name("advanced_search")
                .description("Advanced search for properties on realtor.ca with full control over all search parameters including property type, building type, amenities, size, parking, and more.")
                .inputSchema(Map.of("type","object","properties",props,"required",List.of("city","province")))
                .build();
    }

    // ─── Tool dispatch ────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    public Object callTool(String toolName, Map<String, Object> args) {
        log.info("Calling MCP tool: {} args: {}", toolName, args);

        return switch (toolName) {
            case "search_properties" -> realtorApi.searchProperties(
                    (String) args.get("city"),
                    (String) args.get("province"),
                    toInt(args.get("min_price")),
                    toInt(args.get("max_price")),
                    (String) args.getOrDefault("transaction_type", "for_sale"),
                    toInt(args.getOrDefault("max_results", 50))
            );

            case "advanced_search" -> {
                SearchRequest req = SearchRequest.builder()
                        .city((String) args.get("city"))
                        .province((String) args.get("province"))
                        .minPrice(toInt(args.get("min_price")))
                        .maxPrice(toInt(args.get("max_price")))
                        .transactionType((String) args.getOrDefault("transaction_type","for_sale"))
                        .maxResults(toInt(args.getOrDefault("max_results",50)))
                        .propertyTypeId((String) args.get("property_type_id"))
                        .buildingTypeId((String) args.get("building_type_id"))
                        .constructionStyleId((String) args.get("construction_style_id"))
                        .ownershipTypeId((String) args.get("ownership_type_id"))
                        .minBedrooms(toInt(args.get("min_bedrooms")))
                        .maxBedrooms(toInt(args.get("max_bedrooms")))
                        .minBathrooms(toInt(args.get("min_bathrooms")))
                        .maxBathrooms(toInt(args.get("max_bathrooms")))
                        .minSquareFeet(toInt(args.get("min_square_feet")))
                        .maxSquareFeet(toInt(args.get("max_square_feet")))
                        .minParking(toInt(args.get("min_parking")))
                        .maxParking(toInt(args.get("max_parking")))
                        .minStoreys(toInt(args.get("min_storeys")))
                        .maxStoreys(toInt(args.get("max_storeys")))
                        .airConditioning(toBool(args.get("air_conditioning")))
                        .pool(toBool(args.get("pool")))
                        .fireplace(toBool(args.get("fireplace")))
                        .garage(toBool(args.get("garage")))
                        .keywords((String) args.get("keywords"))
                        .openHouse(toBool(args.get("open_house")))
                        .numberOfDays(toInt(args.get("number_of_days")))
                        .sortOrder((String) args.getOrDefault("sort_order","1-D"))
                        .currentPage(toInt(args.getOrDefault("current_page",1)))
                        .build();
                yield realtorApi.advancedSearch(req);
            }

            default -> Map.of("error", "Unknown tool: " + toolName);
        };
    }

    private Integer toInt(Object v) {
        if (v == null) return null;
        if (v instanceof Integer i) return i;
        if (v instanceof Number n) return n.intValue();
        try { return Integer.parseInt(v.toString()); } catch (Exception e) { return null; }
    }

    private Boolean toBool(Object v) {
        if (v == null) return null;
        if (v instanceof Boolean b) return b;
        return Boolean.parseBoolean(v.toString());
    }
}
