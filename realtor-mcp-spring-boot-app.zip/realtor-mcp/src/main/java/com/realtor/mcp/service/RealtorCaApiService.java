package com.realtor.mcp.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.realtor.mcp.model.Property;
import com.realtor.mcp.model.SearchRequest;
import com.realtor.mcp.model.SearchResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Java port of the Python realtor.ca MCP server.py.
 * Implements:
 *  - get_geo_coordinates()  → Nominatim geocoding (same as Python)
 *  - get_reese84_token()    → realtor.ca authentication
 *  - search_properties()    → basic search tool
 *  - advanced_search()      → full-parameter search tool
 *  - format_property()      → clean property output structure
 */
@Slf4j
@Service
public class RealtorCaApiService {

    private static final String SEARCH_API_ENDPOINT =
            "https://api2.realtor.ca/Listing.svc/PropertySearch_Post";
    private static final String TOKEN_URL =
            "https://www.realtor.ca/dnight-Exit-shall-Braith-Then-why-vponst-is-proc";
    private static final String NOMINATIM_URL =
            "https://nominatim.openstreetmap.org/search";

    private final ObjectMapper objectMapper;

    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .followRedirects(java.net.http.HttpClient.Redirect.NORMAL)
            .build();

    public RealtorCaApiService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    // ─── geocoding (Nominatim — same approach as Python) ────────────────────

    public Optional<Map<String, Double>> getGeoCoordinates(String city, String province) {
        try {
            String query = city + ", " + province + ", Canada";
            String url = NOMINATIM_URL + "?q=" + URLEncoder.encode(query, StandardCharsets.UTF_8)
                    + "&format=json&limit=1&countrycodes=ca";

            HttpRequest req = HttpRequest.newBuilder().uri(URI.create(url))
                    .header("User-Agent", "RealtorMCP-Java/1.0")
                    .GET().timeout(Duration.ofSeconds(10)).build();

            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200) return Optional.empty();

            JsonNode arr = objectMapper.readTree(resp.body());
            if (!arr.isArray() || arr.size() == 0) return Optional.empty();

            JsonNode loc = arr.get(0);
            double lat = loc.path("lat").asDouble();
            double lon = loc.path("lon").asDouble();

            // Same bounding box as Python: ~50 km radius
            double latDelta = 0.45;
            double lonDelta = 0.60;

            Map<String, Double> coords = new LinkedHashMap<>();
            coords.put("LatitudeMin",  lat - latDelta);
            coords.put("LatitudeMax",  lat + latDelta);
            coords.put("LongitudeMin", lon - lonDelta);
            coords.put("LongitudeMax", lon + lonDelta);
            return Optional.of(coords);

        } catch (Exception e) {
            log.error("Geocoding error for {}, {}: {}", city, province, e.getMessage());
            return Optional.empty();
        }
    }

    // ─── reese84 auth token (same endpoint as Python) ───────────────────────

    private String getReese84Token() {
        try {
            Map<String, Object> body1 = new HashMap<>();
            Map<String, Object> solution = new HashMap<>();
            solution.put("interrogation", null);
            solution.put("version", "beta");
            body1.put("solution", solution);
            body1.put("old_token", null);
            body1.put("error", null);

            Map<String, Object> performance = new HashMap<>();
            performance.put("interrogation", 1897);
            body1.put("performance", performance);

            String body = objectMapper.writeValueAsString(body1);

            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(TOKEN_URL + "?d=www.realtor.ca"))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .timeout(Duration.ofSeconds(30)).build();

            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200) {
                return objectMapper.readTree(resp.body()).path("token").asText("");
            }
            log.info("Token request returned {}", resp.statusCode());
            return "";
        } catch (Exception e) {
            e.printStackTrace();
            log.error("Could not get reese84 token: {}", e.getMessage());
            return "";
        }
    }

    // ─── format_property — mirrors Python exactly ────────────────────────────

    private Property formatProperty(JsonNode prop) {
        try {
            JsonNode building = prop.path("Building");
            JsonNode property = prop.path("Property");
            JsonNode address  = property.path("Address");

            String listingUrl = "N/A";
            if (!prop.path("RelativeDetailsURL").isMissingNode() && !prop.path("RelativeDetailsURL").isNull())
                listingUrl = "https://www.realtor.ca" + prop.path("RelativeDetailsURL").asText();

            String photoUrl = "N/A";
            JsonNode photos = property.path("Photo");
            if (photos.isArray() && photos.size() > 0)
                photoUrl = photos.get(0).path("HighResPath").asText("N/A");

            return Property.builder()
                    .mlsNumber(prop.path("MlsNumber").asText("N/A"))
                    .price(property.path("Price").asText("N/A"))
                    .address(Property.Address.builder()
                            .street(address.path("AddressText").asText("N/A"))
                            .city(address.path("City").asText("N/A"))
                            .province(address.path("Province").asText("N/A"))
                            .postalCode(address.path("PostalCode").asText("N/A"))
                            .build())
                    .propertyType(property.path("Type").asText("N/A"))
                    .bedrooms(building.path("Bedrooms").asText("N/A"))
                    .bathrooms(building.path("BathroomTotal").asText("N/A"))
                    .squareFeet(building.path("SizeInterior").asText("N/A"))
                    .description(prop.path("PublicRemarks").asText("N/A"))
                    .photoUrl(photoUrl)
                    .listingUrl(listingUrl)
                    .build();
        } catch (Exception e) {
            log.error("Error formatting property: {}", e.getMessage());
            return Property.builder().mlsNumber("ERROR").description(e.getMessage()).build();
        }
    }

    // ─── core search method used by both tools ───────────────────────────────

    private SearchResult executeSearch(SearchRequest req) {
        // 1. Geocode
        Optional<Map<String, Double>> coords = getGeoCoordinates(req.getCity(), req.getProvince());
        if (coords.isEmpty()) {
            return SearchResult.builder().success(false)
                    .error("Could not find coordinates for " + req.getCity() + ", " + req.getProvince())
                    .build();
        }

        try {
            // 2. Build form parameters (exactly like Python)
            Map<String, String> params = new LinkedHashMap<>();
            params.put("Version", "7.0");
            params.put("ApplicationId", "1");
            params.put("CultureId", "1");
            params.put("Currency", "CAD");
            int limit = Math.min(req.getMaxResults() != null ? req.getMaxResults() : 50, 200);
            params.put("RecordsPerPage", String.valueOf(limit));
            params.put("MaximumResults", String.valueOf(limit));
            params.put("CurrentPage",    String.valueOf(req.getCurrentPage() != null ? req.getCurrentPage() : 1));
            params.put("Sort",           req.getSortOrder() != null ? req.getSortOrder() : "1-D");
            params.put("ZoomLevel",      "10");

            // Transaction type
            boolean isRent = "for_rent".equalsIgnoreCase(req.getTransactionType());
            params.put("TransactionTypeId", isRent ? "3" : "2");

            // Price
            if (req.getMinPrice() != null) params.put(isRent ? "RentMin" : "PriceMin", String.valueOf(req.getMinPrice()));
            if (req.getMaxPrice() != null) params.put(isRent ? "RentMax" : "PriceMax", String.valueOf(req.getMaxPrice()));

            // Advanced filters
            if (req.getPropertyTypeId()      != null) params.put("PropertyTypeId",       req.getPropertyTypeId());
            if (req.getBuildingTypeId()       != null) params.put("BuildingTypeId",        req.getBuildingTypeId());
            if (req.getConstructionStyleId()  != null) params.put("ConstructionStyleId",   req.getConstructionStyleId());
            if (req.getOwnershipTypeId()      != null) params.put("OwnershipTypeGroupId",  req.getOwnershipTypeId());

            if (req.getMinBedrooms() != null || req.getMaxBedrooms() != null)
                params.put("BedRange", nvl(req.getMinBedrooms()) + "-" + nvl(req.getMaxBedrooms()));

            if (req.getMinBathrooms() != null || req.getMaxBathrooms() != null)
                params.put("BathRange", nvl(req.getMinBathrooms()) + "-" + nvl(req.getMaxBathrooms()));

            if (req.getMinSquareFeet() != null || req.getMaxSquareFeet() != null)
                params.put("SizeRange", nvl(req.getMinSquareFeet()) + "-" + nvl(req.getMaxSquareFeet()));

            if (req.getMinParking() != null || req.getMaxParking() != null)
                params.put("ParkingSpaceRange", nvl(req.getMinParking()) + "-" + nvl(req.getMaxParking()));

            if (req.getMinStoreys() != null || req.getMaxStoreys() != null)
                params.put("StoreyRange", nvl(req.getMinStoreys()) + "-" + nvl(req.getMaxStoreys()));

            if (req.getKeywords()       != null) params.put("Keywords",       req.getKeywords());
            if (req.getOpenHouse()      != null) params.put("OpenHouse",      req.getOpenHouse() ? "true" : "false");
            if (req.getAirConditioning()!= null) params.put("AirConditioning",req.getAirConditioning() ? "true" : "false");
            if (req.getPool()           != null) params.put("Pool",           req.getPool() ? "true" : "false");
            if (req.getFireplace()      != null) params.put("Fireplace",      req.getFireplace() ? "true" : "false");
            if (req.getGarage()         != null) params.put("Garage",         req.getGarage() ? "true" : "false");
            if (req.getNumberOfDays()   != null) params.put("NumberOfDays",   String.valueOf(req.getNumberOfDays()));

            // Geo boundaries
            coords.get().forEach((k, v) -> params.put(k, String.valueOf(v)));

            // 3. Get auth token
            String token = getReese84Token();
            log.info("Token >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+token);

            // 4. Build form-encoded body
            String formBody = params.entrySet().stream()
                    .map(e -> URLEncoder.encode(e.getKey(), StandardCharsets.UTF_8)
                            + "=" + URLEncoder.encode(e.getValue(), StandardCharsets.UTF_8))
                    .collect(Collectors.joining("&"));

            log.info("formBody >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+formBody);

            // 5. POST to realtor.ca
            HttpRequest.Builder reqBuilder = HttpRequest.newBuilder()
                    .uri(URI.create(SEARCH_API_ENDPOINT))
                    .header("Content-Type",  "application/x-www-form-urlencoded; charset=UTF-8")
                    .header("Accept",         "*/*")
                    .header("Accept-Language","en-US,en;q=0.9")
                    .header("Cache-Control",  "no-cache")
                    .header("Connection",     "keep-alive")
                    .header("DNT",            "1")
                    .header("Host",           "api2.realtor.ca")
                    .header("Origin",         "https://www.realtor.ca")
                    .header("Pragma",         "no-cache")
                    .header("Referer",        "https://www.realtor.ca/")
                    .header("Sec-Fetch-Dest", "empty")
                    .header("Sec-Fetch-Mode", "cors")
                    .header("Sec-Fetch-Site", "same-site")
                    .header("User-Agent",     "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36")
                    .POST(HttpRequest.BodyPublishers.ofString(formBody))
                    .timeout(Duration.ofSeconds(30));

            if (!token.isBlank()) reqBuilder.header("Cookie", "reese84=" + token + ";");

            HttpResponse<String> resp = http.send(reqBuilder.build(), HttpResponse.BodyHandlers.ofString());

            if (resp.statusCode() == 403) {
                return SearchResult.builder().success(false)
                        .error("Access forbidden — IP may be blocked by realtor.ca. Try again later.").build();
            }
            if (resp.statusCode() != 200) {
                return SearchResult.builder().success(false)
                        .error("API request failed with status code " + resp.statusCode()).build();
            }

            JsonNode data    = objectMapper.readTree(resp.body());
            JsonNode results = data.path("Results");
            int totalRecords = data.path("Paging").path("TotalRecords").asInt(0);

            List<Property> properties = new ArrayList<>();
            if (results.isArray()) {
                for (JsonNode prop : results) properties.add(formatProperty(prop));
            }

            log.info("Total Records :"+totalRecords);
            log.info("Total properties :"+properties);

            return SearchResult.builder()
                    .success(true)
                    .totalFound(totalRecords)
                    .returned(properties.size())
                    .location(req.getCity() + ", " + req.getProvince())
                    .priceRange(Map.of("min", req.getMinPrice() != null ? req.getMinPrice() : "null",
                                       "max", req.getMaxPrice() != null ? req.getMaxPrice() : "null"))
                    .properties(properties)
                    .build();

        } catch (Exception e) {
            log.error("Search failed", e);
            return SearchResult.builder().success(false).error("Search failed: " + e.getMessage()).build();
        }
    }

    /** Simple search (maps to Python search_properties tool) */
    public SearchResult searchProperties(String city, String province,
                                          Integer minPrice, Integer maxPrice,
                                          String transactionType, Integer maxResults) {
        SearchRequest req = SearchRequest.builder()
                .city(city).province(province)
                .minPrice(minPrice).maxPrice(maxPrice)
                .transactionType(transactionType != null ? transactionType : "for_sale")
                .maxResults(maxResults != null ? maxResults : 50)
                .sortOrder("1-D").currentPage(1)
                .build();
        return executeSearch(req);
    }

    /** Advanced search (maps to Python advanced_search tool) */
    public SearchResult advancedSearch(SearchRequest req) {
        return executeSearch(req);
    }

    private String nvl(Integer v) { return v != null ? String.valueOf(v) : "0"; }
}
