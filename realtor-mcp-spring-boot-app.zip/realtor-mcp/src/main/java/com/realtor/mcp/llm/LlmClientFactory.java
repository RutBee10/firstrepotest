package com.realtor.mcp.llm;

import com.realtor.mcp.model.McpTool;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component @RequiredArgsConstructor
public class LlmClientFactory {

    private final LlmConfig config;
    private final AnthropicLlmClient anthropicClient;
    private final OllamaLlmClient ollamaClient;
    private final PerplexityLlmClient perplexityClient;
    private final GeminiLlmClient geminiClient;
    private final CopilotLlmClient copilotClient;

    public LlmClient activeClient() {
        return switch (config.activeProviderEnum()) {
            case ANTHROPIC  -> anthropicClient;
            case OLLAMA     -> ollamaClient;
            case PERPLEXITY -> perplexityClient;
            case GEMINI     -> geminiClient;
            case COPILOT    -> copilotClient;
        };
    }

    public List<Map<String, Object>> buildToolDefs(List<McpTool> tools) {
        return switch (config.activeProviderEnum()) {
            case ANTHROPIC -> AnthropicLlmClient.buildToolDefs(tools);
            case GEMINI    -> GeminiLlmClient.buildToolDefs(tools);
            default        -> OpenAiCompatibleClient.buildToolDefs(tools);
        };
    }

    public String defaultModel() {
        return switch (config.activeProviderEnum()) {
            case ANTHROPIC  -> config.getAnthropic().getDefaultModel();
            case OLLAMA     -> config.getOllama().getDefaultModel();
            case PERPLEXITY -> config.getPerplexity().getDefaultModel();
            case GEMINI     -> config.getGemini().getDefaultModel();
            case COPILOT    -> config.getCopilot().getDefaultModel();
        };
    }

    public List<String> availableModels() {
        return switch (config.activeProviderEnum()) {
            case ANTHROPIC  -> config.getAnthropic().getModels();
            case OLLAMA     -> config.getOllama().getModels();
            case PERPLEXITY -> config.getPerplexity().getModels();
            case GEMINI     -> config.getGemini().getModels();
            case COPILOT    -> config.getCopilot().getModels();
        };
    }

    public Map<String, Object> allProviderInfo() {
        return Map.of(
                "activeProvider", config.getActiveProvider(),
                "providers", Map.of(
                        "anthropic",  Map.of("models", config.getAnthropic().getModels(),  "default", config.getAnthropic().getDefaultModel()),
                        "ollama",     Map.of("models", config.getOllama().getModels(),     "default", config.getOllama().getDefaultModel()),
                        "perplexity", Map.of("models", config.getPerplexity().getModels(), "default", config.getPerplexity().getDefaultModel()),
                        "gemini",     Map.of("models", config.getGemini().getModels(),     "default", config.getGemini().getDefaultModel()),
                        "copilot",    Map.of("models", config.getCopilot().getModels(),    "default", config.getCopilot().getDefaultModel())
                )
        );
    }
}
