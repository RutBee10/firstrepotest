package com.realtor.mcp.llm;

import lombok.Builder;
import lombok.Data;
import java.util.List;
import java.util.Map;

@Data @Builder
public class LlmRequest {
    private String model;
    private String systemPrompt;
    private List<Map<String, Object>> messages;
    private List<Map<String, Object>> tools;
    private Integer maxTokens;
    private Double temperature;
}
