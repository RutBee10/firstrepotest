package com.realtor.mcp.llm;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;
import java.util.Map;

@Component
public class CopilotLlmClient extends OpenAiCompatibleClient {
    private final LlmConfig config;
    public CopilotLlmClient(LlmConfig config, ObjectMapper objectMapper) { super(objectMapper); this.config = config; }
    @Override public LlmProvider provider() { return LlmProvider.COPILOT; }
    @Override protected String apiUrl() {
        var p = config.getCopilot();
        if (p.isAzureMode()) {
            String base = p.getApiUrl().replaceAll("/$","");
            return base + "/openai/deployments/" + p.getDefaultModel() + "/chat/completions?api-version=" + p.getApiVersion();
        }
        return p.getApiUrl();
    }
    @Override protected String apiKey() { return config.getCopilot().getApiKey(); }
    @Override protected Map<String, String> extraHeaders() {
        if (config.getCopilot().isAzureMode()) return Map.of("api-key", config.getCopilot().getApiKey());
        return Map.of();
    }
}
