package com.realtor.mcp.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.realtor.mcp.model.McpRequest;
import com.realtor.mcp.model.McpResponse;
import com.realtor.mcp.model.McpTool;
import com.realtor.mcp.service.McpToolService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@Slf4j @RestController @RequestMapping("/mcp") @RequiredArgsConstructor
public class McpServerController {

    private final McpToolService mcpToolService;
    private final ObjectMapper objectMapper;

    @Value("${mcp.server.name}")    private String serverName;
    @Value("${mcp.server.version}") private String serverVersion;
    @Value("${mcp.server.description}") private String serverDescription;

    @PostMapping("/jsonrpc")
    public ResponseEntity<McpResponse> handle(@RequestBody McpRequest request) {
        log.info("MCP JSON-RPC: method={} id={}", request.getMethod(), request.getId());
        try {
            Object result = switch (request.getMethod()) {
                case "initialize"    -> handleInit();
                case "tools/list"    -> handleToolsList();
                case "tools/call"    -> handleToolCall(request.getParams());
                case "resources/list"-> Map.of("resources", List.of());
                case "prompts/list"  -> handlePromptsList();
                case "ping"          -> Map.of("pong", true);
                default -> throw new IllegalArgumentException("Unknown method: " + request.getMethod());
            };
            return ResponseEntity.ok(McpResponse.builder().jsonrpc("2.0").id(request.getId()).result(result).build());
        } catch (Exception e) {
            return ResponseEntity.ok(McpResponse.builder().jsonrpc("2.0").id(request.getId())
                    .error(McpResponse.McpError.builder().code(-32603).message(e.getMessage()).build()).build());
        }
    }

    @GetMapping("/health")
    public ResponseEntity<Map<String, Object>> health() {
        return ResponseEntity.ok(Map.of("status","healthy","server",serverName,"version",serverVersion,
                "tools",mcpToolService.listTools().size(),"description",serverDescription));
    }

    @GetMapping("/tools")
    public ResponseEntity<List<McpTool>> tools() {
        return ResponseEntity.ok(mcpToolService.listTools());
    }

    @PostMapping("/tools/{name}")
    public ResponseEntity<Object> invokeTool(@PathVariable String name, @RequestBody Map<String, Object> args) {
        try { return ResponseEntity.ok(mcpToolService.callTool(name, args)); }
        catch (Exception e) { return ResponseEntity.badRequest().body(Map.of("error", e.getMessage())); }
    }

    private Map<String, Object> handleInit() {
        return Map.of(
                "protocolVersion", "2024-11-05",
                "capabilities", Map.of(
                        "tools",     Map.of("listChanged", false),
                        "resources", Map.of("subscribe", false, "listChanged", false),
                        "prompts",   Map.of("listChanged", false)
                ),
                "serverInfo", Map.of("name", serverName, "version", serverVersion, "description", serverDescription)
        );
    }

    private Map<String, Object> handleToolsList() {
        List<Map<String, Object>> toolMaps = new ArrayList<>();
        for (McpTool t : mcpToolService.listTools())
            toolMaps.add(Map.of("name",t.getName(),"description",t.getDescription(),"inputSchema",t.getInputSchema()));
        return Map.of("tools", toolMaps);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> handleToolCall(Map<String, Object> params) {
        String toolName = (String) params.get("name");
        Map<String, Object> args = (Map<String, Object>) params.getOrDefault("arguments", Map.of());
        try {
            Object result = mcpToolService.callTool(toolName, args);
            return Map.of("content", List.of(Map.of("type","text","text",objectMapper.writeValueAsString(result))), "isError", false);
        } catch (Exception e) {
            return Map.of("content", List.of(Map.of("type","text","text","Error: "+e.getMessage())), "isError", true);
        }
    }

    private Map<String, Object> handlePromptsList() {
        return Map.of("prompts", List.of(
                Map.of("name","property_search","description","Search for properties in a Canadian city",
                        "arguments",List.of(
                                Map.of("name","city","description","City name","required",true),
                                Map.of("name","province","description","Province code (e.g. ON, BC)","required",true)
                        )),
                Map.of("name","advanced_property_search","description","Advanced search with full filters",
                        "arguments",List.of(
                                Map.of("name","city","description","City name","required",true),
                                Map.of("name","province","description","Province code","required",true),
                                Map.of("name","filters","description","Additional search filters","required",false)
                        ))
        ));
    }
}
