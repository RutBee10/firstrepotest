package com.realtor.mcp.llm;

public enum LlmProvider {
    ANTHROPIC, OLLAMA, PERPLEXITY, GEMINI, COPILOT
}
