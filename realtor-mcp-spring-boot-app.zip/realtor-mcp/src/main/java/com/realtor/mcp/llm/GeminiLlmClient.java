package com.realtor.mcp.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.realtor.mcp.model.McpTool;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;

@Slf4j @Component @RequiredArgsConstructor
public class GeminiLlmClient implements LlmClient {

    private final LlmConfig config;
    private final ObjectMapper objectMapper;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(30)).build();

    @Override public LlmProvider provider() { return LlmProvider.GEMINI; }

    @Override
    public LlmResponse chat(LlmRequest req) {
        try {
            var p = config.getGemini();
            String url = p.getApiUrl() + "/" + req.getModel() + ":generateContent?key=" + p.getApiKey();

            List<Map<String, Object>> contents = new ArrayList<>();
            for (var msg : req.getMessages()) {
                String role = (String) msg.get("role");
                String gemRole = "assistant".equals(role) ? "model" : "user";
                Object content = msg.get("content");
                if (content instanceof String s) {
                    contents.add(Map.of("role", gemRole, "parts", List.of(Map.of("text", s))));
                } else if (content instanceof List<?> parts) {
                    List<Map<String, Object>> gParts = new ArrayList<>();
                    for (Object part : parts) {
                        if (part instanceof Map m) {
                            String type = (String) m.get("type");
                            if ("tool_result".equals(type)) {
                                gParts.add(Map.of("functionResponse", Map.of(
                                        "name", m.getOrDefault("name", "tool"),
                                        "response", Map.of("content", m.get("content")))));
                            } else if ("tool_use".equals(type)) {
                                gParts.add(Map.of("functionCall", Map.of("name", m.get("name"), "args", m.getOrDefault("input", Map.of()))));
                            } else {
                                gParts.add(Map.of("text", m.getOrDefault("text", "")));
                            }
                        }
                    }
                    if (!gParts.isEmpty()) contents.add(Map.of("role", gemRole, "parts", gParts));
                }
            }

            Map<String, Object> body = new LinkedHashMap<>();
            body.put("contents", contents);
            if (req.getSystemPrompt() != null)
                body.put("systemInstruction", Map.of("parts", List.of(Map.of("text", req.getSystemPrompt()))));
            body.put("generationConfig", Map.of("maxOutputTokens", req.getMaxTokens() != null ? req.getMaxTokens() : 4096));
            if (req.getTools() != null && !req.getTools().isEmpty()) {
                body.put("tools", List.of(Map.of("functionDeclarations", req.getTools())));
                body.put("toolConfig", Map.of("functionCallingConfig", Map.of("mode", "AUTO")));
            }

            HttpRequest httpReq = HttpRequest.newBuilder().uri(URI.create(url))
                    .header("Content-Type","application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(body)))
                    .timeout(Duration.ofSeconds(120)).build();

            HttpResponse<String> resp = http.send(httpReq, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200)
                return LlmResponse.builder().success(false).errorMessage("HTTP " + resp.statusCode() + ": " + resp.body()).build();

            JsonNode root = objectMapper.readTree(resp.body());
            JsonNode candidate = root.path("candidates").path(0);
            String text = "";
            List<LlmResponse.ToolUse> toolUses = new ArrayList<>();
            for (JsonNode part : candidate.path("content").path("parts")) {
                if (part.has("text")) text = part.path("text").asText();
                else if (part.has("functionCall")) {
                    JsonNode fc = part.path("functionCall");
                    toolUses.add(LlmResponse.ToolUse.builder()
                            .id(UUID.randomUUID().toString())
                            .name(fc.path("name").asText())
                            .arguments(objectMapper.convertValue(fc.path("args"), Map.class))
                            .build());
                }
            }
            return LlmResponse.builder().text(text).stopReason(toolUses.isEmpty() ? "STOP" : "tool_calls").toolUses(toolUses).success(true).build();
        } catch (Exception e) {
            log.error("Gemini error", e);
            return LlmResponse.builder().success(false).errorMessage(e.getMessage()).build();
        }
    }

    @Override
    public List<Map<String, Object>> appendToolResult(
            List<Map<String, Object>> messages, List<Map<String, Object>> assistantRaw, List<ToolResult> toolResults) {
        messages.add(Map.of("role","model","content",assistantRaw));
        List<Map<String, Object>> parts = new ArrayList<>();
        for (ToolResult tr : toolResults)
            parts.add(Map.of("type","tool_result","name",tr.toolName(),"content",tr.resultJson()));
        messages.add(Map.of("role","user","content",parts));
        return messages;
    }

    public static List<Map<String, Object>> buildToolDefs(List<McpTool> tools) {
        List<Map<String, Object>> result = new ArrayList<>();
        for (var t : tools)
            result.add(Map.of("name",t.getName(),"description",t.getDescription(),"parameters",t.getInputSchema()));
        return result;
    }
}
