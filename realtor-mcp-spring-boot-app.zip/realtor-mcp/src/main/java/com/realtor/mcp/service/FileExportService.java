package com.realtor.mcp.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVPrinter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Slf4j @Service
public class FileExportService {

    @Value("${output.directory:./output}")
    private String outputDirectory;

    private final ObjectMapper objectMapper;

    public FileExportService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper.copy().enable(SerializationFeature.INDENT_OUTPUT);
    }

    public String exportToJson(Object data, String id) {
        try {
            Path dir = Paths.get(outputDirectory);
            Files.createDirectories(dir);
            String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            Path file = dir.resolve("realtor_" + id + "_" + ts + ".json");
            objectMapper.writeValue(file.toFile(), data);
            log.info("Exported JSON: {}", file);
            return file.toAbsolutePath().toString();
        } catch (Exception e) { log.error("JSON export failed", e); return null; }
    }

    public String exportToCsv(Object data, String id) {
        try {
            Path dir = Paths.get(outputDirectory);
            Files.createDirectories(dir);
            String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
            Path file = dir.resolve("realtor_" + id + "_" + ts + ".csv");

            JsonNode node = objectMapper.valueToTree(data);
            // Try to find the properties array
            JsonNode rows = node.isArray() ? node : node.path("properties");
            if (rows.isMissingNode() || !rows.isArray()) rows = node;

            try (BufferedWriter w = Files.newBufferedWriter(file)) {
                if (rows.isArray() && rows.size() > 0 && rows.get(0).isObject()) {
                    List<String> headers = new ArrayList<>();
                    rows.get(0).fieldNames().forEachRemaining(headers::add);
                    try (CSVPrinter p = new CSVPrinter(w, CSVFormat.DEFAULT.withHeader(headers.toArray(new String[0])))) {
                        for (JsonNode row : rows) {
                            List<Object> vals = new ArrayList<>();
                            for (String h : headers) vals.add(flatten(row.get(h)));
                            p.printRecord(vals);
                        }
                    }
                } else {
                    // Flat key-value
                    try (CSVPrinter p = new CSVPrinter(w, CSVFormat.DEFAULT.withHeader("Field","Value"))) {
                        node.fields().forEachRemaining(e -> {
                            try { p.printRecord(e.getKey(), flatten(e.getValue())); } catch (IOException ex) { log.warn("CSV row error",ex); }
                        });
                    }
                }
            }
            log.info("Exported CSV: {}", file);
            return file.toAbsolutePath().toString();
        } catch (Exception e) { log.error("CSV export failed", e); return null; }
    }

    private String flatten(JsonNode n) {
        if (n == null || n.isNull()) return "";
        if (n.isTextual()) return n.asText();
        if (n.isNumber()) return n.asText();
        if (n.isBoolean()) return n.asText();
        return n.toString();
    }

    public byte[] readFileAsBytes(String path) throws IOException {
        return Files.readAllBytes(Paths.get(path));
    }

    public List<Map<String, String>> listOutputFiles() {
        try {
            Path dir = Paths.get(outputDirectory);
            if (!Files.exists(dir)) return List.of();
            List<Map<String, String>> files = new ArrayList<>();
            Files.list(dir).filter(Files::isRegularFile)
                    .sorted(Comparator.reverseOrder()).limit(50)
                    .forEach(p -> {
                        Map<String, String> m = new LinkedHashMap<>();
                        m.put("name", p.getFileName().toString());
                        m.put("path", p.toAbsolutePath().toString());
                        m.put("type", p.toString().endsWith(".csv") ? "CSV" : "JSON");
                        try { m.put("size", Files.size(p) + " bytes"); } catch (IOException e) { m.put("size","?"); }
                        files.add(m);
                    });
            return files;
        } catch (Exception e) { return List.of(); }
    }
}
