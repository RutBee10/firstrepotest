package com.realtor.mcp.llm;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import java.util.List;

@Data
@Component
@ConfigurationProperties(prefix = "llm")
public class LlmConfig {

    private String activeProvider = "anthropic";
    private AnthropicProps anthropic = new AnthropicProps();
    private OllamaProps ollama = new OllamaProps();
    private PerplexityProps perplexity = new PerplexityProps();
    private GeminiProps gemini = new GeminiProps();
    private CopilotProps copilot = new CopilotProps();

    @Data public static class AnthropicProps {
        private String apiKey = "";
        private String apiUrl = "https://api.anthropic.com/v1/messages";
        private String apiVersion = "2023-06-01";
        private String defaultModel = "claude-sonnet-4-6";
        private List<String> models = List.of("claude-sonnet-4-6","claude-opus-4-6","claude-haiku-4-5-20251001");
    }

    @Data public static class OllamaProps {
        private String apiUrl = "http://localhost:11434";
        private String defaultModel = "llama3.2";
        private List<String> models = List.of("llama3.2","llama3.1","mistral","mixtral","gemma2","phi3","qwen2.5","deepseek-r1");
    }

    @Data public static class PerplexityProps {
        private String apiKey = "";
        private String apiUrl = "https://api.perplexity.ai/chat/completions";
        private String defaultModel = "llama-3.1-sonar-large-128k-online";
        private List<String> models = List.of("llama-3.1-sonar-large-128k-online","llama-3.1-sonar-small-128k-online","llama-3.1-sonar-huge-128k-online","llama-3.1-8b-instruct","llama-3.1-70b-instruct");
    }

    @Data public static class GeminiProps {
        private String apiKey = "AIzaSyCsjKSUP9S5zbUbmqmF7ReXVUoXCrBaVBo";
        private String apiUrl = "https://generativelanguage.googleapis.com/v1beta/models";
        private String defaultModel = "gemini-2.5-flash";
        private List<String> models = List.of("gemini-2.5-flash","gemini-3.1-pro","gemini-2.0-flash-exp","gemini-3.1-pro-preview");
    }

    @Data public static class CopilotProps {
        private String apiUrl = "https://api.openai.com/v1/chat/completions";
        private String apiKey = "";
        private String defaultModel = "gpt-4o";
        private String apiVersion = "2024-02-01";
        private boolean azureMode = false;
        private List<String> models = List.of("gpt-4o","gpt-4o-mini","gpt-4-turbo","gpt-4","gpt-3.5-turbo");
    }

    public LlmProvider activeProviderEnum() {
        return LlmProvider.valueOf(activeProvider.toUpperCase());
    }
}
