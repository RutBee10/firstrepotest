package com.realtor.mcp.llm;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

@Component
public class OllamaLlmClient extends OpenAiCompatibleClient {
    private final LlmConfig config;
    public OllamaLlmClient(LlmConfig config, ObjectMapper objectMapper) { super(objectMapper); this.config = config; }
    @Override public LlmProvider provider() { return LlmProvider.OLLAMA; }
    @Override protected String apiUrl() { return config.getOllama().getApiUrl().replaceAll("/$","") + "/v1/chat/completions"; }
    @Override protected String apiKey() { return "ollama"; }
}
