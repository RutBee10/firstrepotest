package com.realtor.mcp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealtorMcpApplication {
    public static void main(String[] args) {
        System.setProperty("jdk.httpclient.allowRestrictedHeaders", "Connection,Host");
        SpringApplication.run(RealtorMcpApplication.class, args);
    }
}
