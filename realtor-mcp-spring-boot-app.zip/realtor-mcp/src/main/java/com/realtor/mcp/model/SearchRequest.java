package com.realtor.mcp.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class SearchRequest {

    // Required
    private String city;
    private String province;

    // Basic filters
    @JsonProperty("min_price")
    private Integer minPrice;

    @JsonProperty("max_price")
    private Integer maxPrice;

    @JsonProperty("transaction_type")
    private String transactionType = "for_sale";

    @JsonProperty("max_results")
    private Integer maxResults = 50;

    // Property type
    @JsonProperty("property_type_id")
    private String propertyTypeId;

    @JsonProperty("building_type_id")
    private String buildingTypeId;

    @JsonProperty("construction_style_id")
    private String constructionStyleId;

    @JsonProperty("ownership_type_id")
    private String ownershipTypeId;

    // Size & features
    @JsonProperty("min_bedrooms")
    private Integer minBedrooms;

    @JsonProperty("max_bedrooms")
    private Integer maxBedrooms;

    @JsonProperty("min_bathrooms")
    private Integer minBathrooms;

    @JsonProperty("max_bathrooms")
    private Integer maxBathrooms;

    @JsonProperty("min_square_feet")
    private Integer minSquareFeet;

    @JsonProperty("max_square_feet")
    private Integer maxSquareFeet;

    @JsonProperty("min_parking")
    private Integer minParking;

    @JsonProperty("max_parking")
    private Integer maxParking;

    @JsonProperty("min_storeys")
    private Integer minStoreys;

    @JsonProperty("max_storeys")
    private Integer maxStoreys;

    // Amenities
    @JsonProperty("air_conditioning")
    private Boolean airConditioning;

    private Boolean pool;
    private Boolean fireplace;
    private Boolean garage;

    // Other
    private String keywords;

    @JsonProperty("open_house")
    private Boolean openHouse;

    @JsonProperty("number_of_days")
    private Integer numberOfDays;

    @JsonProperty("sort_order")
    private String sortOrder = "1-D";

    @JsonProperty("current_page")
    private Integer currentPage = 1;
}
