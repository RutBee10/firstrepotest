package com.realtor.mcp.llm;

import lombok.Builder;
import lombok.Data;
import java.util.List;
import java.util.Map;

@Data @Builder
public class LlmResponse {
    private String text;
    private String stopReason;
    private List<ToolUse> toolUses;
    private boolean success;
    private String errorMessage;

    @Data @Builder
    public static class ToolUse {
        private String id;
        private String name;
        private Map<String, Object> arguments;
    }
}
