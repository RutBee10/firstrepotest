package com.realtor.mcp.llm;

import java.util.List;
import java.util.Map;

public interface LlmClient {

    LlmProvider provider();

    LlmResponse chat(LlmRequest request);

    List<Map<String, Object>> appendToolResult(
            List<Map<String, Object>> messages,
            List<Map<String, Object>> assistantRaw,
            List<ToolResult> toolResults
    );

    record ToolResult(String toolCallId, String toolName, String resultJson) {}
}
