package com.realtor.mcp.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.realtor.mcp.model.McpTool;
import lombok.extern.slf4j.Slf4j;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;

@Slf4j
public abstract class OpenAiCompatibleClient implements LlmClient {

    protected final ObjectMapper objectMapper;
    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(30)).build();

    protected OpenAiCompatibleClient(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    protected abstract String apiUrl();
    protected abstract String apiKey();
    protected Map<String, String> extraHeaders() { return Map.of(); }

    @Override
    public LlmResponse chat(LlmRequest req) {
        try {
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("model", req.getModel());
            body.put("max_tokens", req.getMaxTokens() != null ? req.getMaxTokens() : 4096);
            if (req.getTemperature() != null) body.put("temperature", req.getTemperature());

            List<Map<String, Object>> msgs = new ArrayList<>();
            if (req.getSystemPrompt() != null)
                msgs.add(Map.of("role", "system", "content", req.getSystemPrompt()));
            msgs.addAll(req.getMessages());
            body.put("messages", msgs);

            if (req.getTools() != null && !req.getTools().isEmpty()) {
                body.put("tools", req.getTools());
                body.put("tool_choice", "auto");
            }

            HttpRequest.Builder builder = HttpRequest.newBuilder()
                    .uri(URI.create(apiUrl()))
                    .header("Content-Type", "application/json")
                    .timeout(Duration.ofSeconds(120));

            String key = apiKey();
            if (key != null && !key.isBlank()) builder.header("Authorization", "Bearer " + key);
            extraHeaders().forEach(builder::header);
            builder.POST(HttpRequest.BodyPublishers.ofString(objectMapper.writeValueAsString(body)));

            HttpResponse<String> resp = http.send(builder.build(), HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200)
                return LlmResponse.builder().success(false)
                        .errorMessage("HTTP " + resp.statusCode() + ": " + resp.body()).build();

            JsonNode root = objectMapper.readTree(resp.body());
            JsonNode choice = root.path("choices").path(0);
            String finishReason = choice.path("finish_reason").asText("stop");
            JsonNode message = choice.path("message");

            String text = message.path("content").asText("");
            List<LlmResponse.ToolUse> toolUses = new ArrayList<>();
            for (JsonNode tc : message.path("tool_calls")) {
                String argsJson = tc.path("function").path("arguments").asText("{}");
                toolUses.add(LlmResponse.ToolUse.builder()
                        .id(tc.path("id").asText())
                        .name(tc.path("function").path("name").asText())
                        .arguments(objectMapper.readValue(argsJson, Map.class))
                        .build());
            }

            return LlmResponse.builder()
                    .text(text).stopReason(toolUses.isEmpty() ? finishReason : "tool_calls")
                    .toolUses(toolUses).success(true).build();

        } catch (Exception e) {
            log.error("{} error", provider(), e);
            return LlmResponse.builder().success(false).errorMessage(e.getMessage()).build();
        }
    }

    @Override
    public List<Map<String, Object>> appendToolResult(
            List<Map<String, Object>> messages,
            List<Map<String, Object>> assistantRaw,
            List<ToolResult> toolResults) {
        messages.add(Map.of("role", "assistant", "content", assistantRaw));
        for (ToolResult tr : toolResults)
            messages.add(Map.of("role","tool","tool_call_id",tr.toolCallId(),"name",tr.toolName(),"content",tr.resultJson()));
        return messages;
    }

    public static List<Map<String, Object>> buildToolDefs(List<McpTool> tools) {
        List<Map<String, Object>> result = new ArrayList<>();
        for (var t : tools)
            result.add(Map.of("type","function","function",Map.of(
                    "name", t.getName(),
                    "description", t.getDescription(),
                    "parameters", t.getInputSchema())));
        return result;
    }
}
