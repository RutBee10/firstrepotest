package com.realtor.mcp.controller;

import com.realtor.mcp.llm.LlmClientFactory;
import com.realtor.mcp.llm.LlmConfig;
import com.realtor.mcp.model.ChatRequest;
import com.realtor.mcp.model.ChatResponse;
import com.realtor.mcp.service.FileExportService;
import com.realtor.mcp.service.LlmService;
import com.realtor.mcp.service.McpToolService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.List;
import java.util.Map;

@Slf4j @Controller @RequiredArgsConstructor
public class ChatController {

    private final LlmService llmService;
    private final LlmClientFactory clientFactory;
    private final LlmConfig llmConfig;
    private final FileExportService fileExportService;
    private final McpToolService mcpToolService;

    @Value("${mcp.server.name}") private String serverName;

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("serverName",    serverName);
        model.addAttribute("activeProvider",llmConfig.getActiveProvider());
        model.addAttribute("defaultModel",  clientFactory.defaultModel());
        model.addAttribute("providerInfo",  clientFactory.allProviderInfo());
        model.addAttribute("recentFiles",   fileExportService.listOutputFiles());
        return "index";
    }

    @PostMapping("/api/chat")
    @ResponseBody
    public ResponseEntity<ChatResponse> chat(@RequestBody ChatRequest request) {
        log.info("Chat: provider={} model={}", llmConfig.getActiveProvider(), request.getModel());
        return ResponseEntity.ok(llmService.chat(request));
    }

    @GetMapping("/api/providers")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> providers() {
        return ResponseEntity.ok(clientFactory.allProviderInfo());
    }

    @GetMapping("/api/tools")
    @ResponseBody
    public ResponseEntity<Object> tools() {
        return ResponseEntity.ok(Map.of("tools", mcpToolService.listTools()));
    }

    @GetMapping("/api/files")
    @ResponseBody
    public ResponseEntity<List<Map<String, String>>> files() {
        return ResponseEntity.ok(fileExportService.listOutputFiles());
    }

    @GetMapping("/api/files/download")
    public ResponseEntity<Resource> download(@RequestParam String path) {
        try {
            byte[] data = fileExportService.readFileAsBytes(path);
            String name = Paths.get(path).getFileName().toString();
            MediaType mt = name.endsWith(".csv") ? MediaType.parseMediaType("text/csv") : MediaType.APPLICATION_JSON;
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + name + "\"")
                    .contentType(mt).body(new ByteArrayResource(data));
        } catch (IOException e) { return ResponseEntity.notFound().build(); }
    }
}
