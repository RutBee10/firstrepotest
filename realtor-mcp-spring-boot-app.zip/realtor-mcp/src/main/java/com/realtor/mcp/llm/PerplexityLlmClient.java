package com.realtor.mcp.llm;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Component;

@Component
public class PerplexityLlmClient extends OpenAiCompatibleClient {
    private final LlmConfig config;
    public PerplexityLlmClient(LlmConfig config, ObjectMapper objectMapper) { super(objectMapper); this.config = config; }
    @Override public LlmProvider provider() { return LlmProvider.PERPLEXITY; }
    @Override protected String apiUrl() { return config.getPerplexity().getApiUrl(); }
    @Override protected String apiKey() { return config.getPerplexity().getApiKey(); }
}
