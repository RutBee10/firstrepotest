package com.realtor.mcp.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class ChatRequest {
    private String message;
    private String model;
    private Integer maxTokens = 4096;
}
