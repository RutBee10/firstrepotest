package com.realtor.mcp.service;

import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpStatusCodeException;
import java.util.HashMap;
import java.util.Map;

public class RealtorService {

    private final RestTemplate restTemplate;

    public RealtorService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getReese84Token() {
        String url = "https://www.realtor.ca/dnight-Exit-shall-Braith-Then-why-vponst-is-proc";

        // Build request body
        Map<String, Object> body = new HashMap<>();
        Map<String, Object> solution = new HashMap<>();
        solution.put("interrogation", null);
        solution.put("version", "beta");
        body.put("solution", solution);
        body.put("old_token", null);
        body.put("error", null);

        Map<String, Object> performance = new HashMap<>();
        performance.put("interrogation", 1897);
        body.put("performance", performance);

        // Build headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<Map<String, Object>> requestEntity = new HttpEntity<>(body, headers);

        try {
            ResponseEntity<Map> response = restTemplate.exchange(
                    url + "?d=www.realtor.ca",
                    HttpMethod.POST,
                    requestEntity,
                    Map.class
            );

            if (response.getStatusCode() == HttpStatus.OK) {
                Map<String, Object> responseBody = response.getBody();
                if (responseBody != null && responseBody.containsKey("token")) {
                    return responseBody.get("token").toString();
                } else {
                    throw new RuntimeException("Token not found in response");
                }
            } else {
                throw new RuntimeException("Failed to get reese84 token: status " + response.getStatusCode());
            }
        } catch (HttpStatusCodeException e) {
            throw new RuntimeException("Error getting reese84 token: " + e.getResponseBodyAsString(), e);
        } catch (Exception e) {
            throw new RuntimeException("Error getting reese84 token: " + e.getMessage(), e);
        }
    }
}
