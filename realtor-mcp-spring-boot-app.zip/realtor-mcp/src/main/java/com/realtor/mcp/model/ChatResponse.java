package com.realtor.mcp.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ChatResponse {
    private String conversationId;
    private String message;
    private String model;
    private LocalDateTime timestamp;
    private Object jsonData;
    private String csvFilePath;
    private String jsonFilePath;
    private List<ToolCall> toolCalls;
    private boolean success;
    private String error;

    @Data @Builder @NoArgsConstructor @AllArgsConstructor
    public static class ToolCall {
        private String toolName;
        private Object input;
        private Object result;
    }
}
