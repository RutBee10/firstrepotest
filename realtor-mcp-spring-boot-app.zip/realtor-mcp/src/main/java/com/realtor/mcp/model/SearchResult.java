package com.realtor.mcp.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Map;

@Data @Builder @NoArgsConstructor @AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SearchResult {
    private boolean success;
    private String error;

    @JsonProperty("total_found")
    private Integer totalFound;

    private Integer returned;
    private String location;

    @JsonProperty("price_range")
    private Map<String, Object> priceRange;

    private Map<String, Object> filters;
    private List<Property> properties;
}
